var gameStart = {
    gameListBtn :  null,
    gameListDom : null,
    gameListFrame : null,
    gamePath : null ,
    gameCloseBtn : null,
    gameDestroy :  null,
    scene_selectTeam : null,
    scene_selectCard : null,
    scene_game : null,
    scene_complete : null,
    layer_team : null,
    isStartGame : false
};

gameStart.init = function(){

    this.gameListBtn = document.querySelector('#_game button');
    this.gameListDom = document.querySelector('#_pop_game');
    this.gameListFrame = this.gameListDom.querySelector('#game_frame');
    this.gameCloseBtn = this.gameListDom.querySelector('._btn_game_close');
    this.gamePath = window.parent.VIEWER.global_value.content_directory + 'game/';


    //팀 선택
    this.scene_selectTeam = document.querySelector('#gameIntro');
    //카드 선택
    this.scene_selectCard = document.querySelector('#gameSelect');
    //게임 화면
    this.scene_game = document.querySelector('#gameWrap');
    //결과 화면
    this.scene_complete = document.querySelector('#gameWrap_complete');
    //팀 선택
    this.layer_team = document.querySelector('#teamList');


    try {
        this.eventBind();
    } catch (e) {
        console.error(e);
    }
};

gameStart.eventBind = function(){

    var self = this;

    //열기 버튼
    this.gameListBtn.addEventListener('click' , function(e){
        self.gameListFrame.src = self.gamePath + 'gameSelect.html';
    });

    //닫기 버튼
    this.gameCloseBtn.addEventListener('click' , function(e){
        if(window.VIEWER.basic.bStartGame) {
            self.gameListFrame.src = self.gamePath + 'gameSelect.html';
        } else {
            self.gameListDom.style.display = 'none';
            console.log('self.gameDestroy ::::: ', self.gameDestroy);
            if (self.gameDestroy) self.gameDestroy();
            if (document.getElementById('game_frame').contentWindow.bgmAudio) {
                document.getElementById('game_frame').contentWindow.bgmAudio.pause();
            }
            self.gameListFrame.src = null;
        }
        window.VIEWER.basic.bStartGame = false;
    });
};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {

    try {
        gameStart.init();
    } catch (e) {
        console.error('gameStart init error :', e);
    }
});