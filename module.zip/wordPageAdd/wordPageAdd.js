var wordPageAdd = {
    pagePath : null ,
    wordPage_iframe : null ,
    wordPage_btn : null ,
    wordPage_layer : null,
    wordPage_closeBtn : null
};


wordPageAdd.init = function(){

    this.pagePath = VIEWER.global_value.content_directory + 'wordRoom/wordRoom.html';
    this.wordPage_btn = document.querySelector('#_word button');
    this.wordPage_iframe = document.querySelector('#word_frame');
    this.wordPage_layer = document.querySelector('#_pop_word');
    this.wordPage_closeBtn = document.querySelector('#_pop_word_wrap ._btn_word_close');
    this.wordPage_iframe.src = this.pagePath;

    this.evtBind();
};

wordPageAdd.evtBind = function(){
    var self = this;

    this.wordPage_btn.addEventListener('click' , function(){
        self.wordPage_iframe.src = self.pagePath;
        self.wordPage_layer.style.display = 'block';
    });

    this.wordPage_closeBtn.addEventListener('click' , function(){
        self.wordPage_iframe.src = '';
        self.wordPage_layer.style.display = 'none';
    });
};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        wordPageAdd.init();
    } catch (e) {
        console.error('wordPageAdd init error :', e);
    }
});