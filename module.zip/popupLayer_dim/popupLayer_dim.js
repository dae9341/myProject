var popup_dim = {
    popup_dimLayer :null,
    popupLayer : null,
    btn_dim : null
};

popup_dim.init = function () {
    var self = this;


    self.popup_dimLayer = document.querySelector('#_popupLayer_layer');
    self.btn_dim = document.querySelector('#_popupLayer_ggam');
    self.popupLayer = document.querySelector('#_ggamLayer');

    self.popupLayer.style.width = '100%';
    self.popupLayer.style.height = '100%';
    self.popupLayer.style.position = 'absolute';
    self.popupLayer.style.display = 'none';
    self.popupLayer.style.top = '0px';
    self.popupLayer.style.left = '0px';
    self.popupLayer.style.backgroundColor = '#000000';
    self.popupLayer.style.zIndex = '1000';



    try {
        self.bindEvent();
    }catch (e){
        console.error('timer bindEvent error :' , e);
    }
};

popup_dim.bindEvent = function () {
    var self = this;

    self.btn_dim.addEventListener('click', function () {
        self.popupLayer.style.display = 'block';
        self.popup_dimLayer.classList.add('on');
    });

    self.popupLayer.addEventListener('click', function () {
       this.style.display = 'none';
        self.popup_dimLayer.classList.remove('on');
    });
};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        popup_dim.init();
    } catch (e) {
        console.error('timer init error :', e);
    }
});


