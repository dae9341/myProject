var popup_pen = {
    key : 'pen',
    viewer : null,
    popupLayer : null,
    btn_pen : null,
    btn_close : null,
    canvasWrap : null,
    canvas : null,
    canvas_save : null,
    ctx : null,
    color : '#000',
    type : 'p' ,
    brush : 'pen' ,
    size : 4,
    eraser_1 : null,
    eraser_2 : null,
    mouseEvent : true,
    pathData : new Array(),
    eraser_undo : null,
    save_ctx : null,
    start_x : new Array(),
    start_y : new Array(),
    end_x : new Array(),
    end_y : new Array(),
    resizeValue : null
};

var popup_pen_pos = {
    drawable : false,
    x: -1,
    y: -1
};

var popup_pen_temp_pos ={
        start_x:'',
        start_y:'',
        end_x:'',
        end_y:''
};




popup_pen.init = function () {
    var self = this;
    self.btn_pen = document.querySelector('#_popupLayer_pen');
    self.popupLayer = document.querySelector('#_penLayer');
    self.eraser_1 = self.popupLayer.querySelector('._popupLayer_eraser_all');
    self.eraser_undo = self.popupLayer.querySelector('._popupLayer_eraser_step');

    self.canvasWrap = document.querySelector('#_popupLayer_canvas_container');
    self.canvas = document.querySelector('#__popupLayer_pen_canvas');
    self.canvas_save = document.querySelector('#__popupLayer_pen_canvas_save');

    self.ctx = self.canvas.getContext("2d");
    self.save_ctx = self.canvas_save.getContext("2d");

    self.resizeValue = parseFloat(document.querySelector('#viewer_wrap').style.transform.substring(28,34));


    self.canvas.setAttribute('width' , '1260px');
    self.canvas.setAttribute('height' , '835px');
    self.canvas_save.setAttribute('width' , '1260px');
    self.canvas_save.setAttribute('height' , '835px');

    try {
        self.bindEvent();
    }catch (e){
        console.error('pen bindEvent error :' , e);
    }


};




popup_pen.bindEvent = function () {

    var self = this;

    self.btn_pen.addEventListener('click' , function () {
        var btnStatus = this.classList.contains('on');
        if(!btnStatus){
            this.classList.add('on');
            self.popupLayer.classList.add('on');

            self.canvasWrap.style.display = 'block';
            self.canvas.style.pointerEvents = 'auto';
            self.canvas_save.style.pointerEvents = 'auto';
            self.mouseEvent = true;
        }else{
            this.classList.remove('on');
            self.popupLayer.classList.remove('on');

            self.canvas.classList.remove('on');
            self.canvas.style.pointerEvents = 'none';
            self.canvas_save.style.pointerEvents = 'none';
            self.mouseEvent = false;
        }
    });

    self.eraser_1.addEventListener('click', function () {
        self.save_ctx.clearRect( 0 , 0 , self.canvas.width , self.canvas.height);
        self.pathData = [];
        self.nwSaveData(self.pathData);
    });

    self.eraser_undo.addEventListener('click', function () {
        if(self.pathData){
            self.pathData.pop();
        }
        self.save_ctx.clearRect( 0 , 0 , self.canvas_save.width , self.canvas_save.height);

        if(self.pathData) {
            for (var i = 0; i < self.pathData.length; i++) {
                self.viewCanvasDraw(self.pathData[i]);
            }
        }
    });

    $('#_popupLayer_penLayer_wrap').find('._popupLayer_pen').on('click',function () {
        $('#_popupLayer_penLayer_wrap').find('._popupLayer_marker').removeClass('select');
        $(this).addClass('select');
        self.type = 'p';
        self.size = 4;
    });

    $('#_popupLayer_penLayer_wrap').find('._popupLayer_marker').on('click',function () {
        $('#_popupLayer_penLayer_wrap').find('._popupLayer_pen').removeClass('select');
        $(this).addClass('select');
        self.type = 'm';
        self.size = 15;
    });
    
    $('#_popupLayer_penLayer_wrap').find('._popupLayer_color').on('click', function () {
        $('#_popupLayer_penLayer_wrap').find('._popupLayer_color').removeClass('select');
        $(this).addClass('select');
        self.color = $(this).css('background-color');
    });

    self.canvas.addEventListener('mousedown', popup_pen.listener);
    self.canvas.addEventListener('mousemove', popup_pen.listener);
    self.canvas.addEventListener('mouseup', popup_pen.listener);

    self.canvas.addEventListener('touchstart', popup_pen.listener);
    self.canvas.addEventListener('touchmove', popup_pen.listener);
    self.canvas.addEventListener('touchend', popup_pen.listener);


    document.querySelector('#_popupLayer_close').addEventListener('click', function () {
        popup_pen.deleteLayer();
    });
};

popup_pen.listener = function (event) {

    if(popup_pen.mouseEvent) {
        switch (event.type) {
            case 'mousedown':
            case 'touchstart':
                popup_pen.drawWrap = true;
                popup_pen.initDraw(event, popup_pen.type, popup_pen.color, popup_pen.size);
                break;
            case 'mousemove':
            case 'touchmove':
                if(popup_pen_pos.drawable){
                    if(popup_pen.drawWrap){
                        if (popup_pen.brush === 'pen') {
                            popup_pen.drawing(event);
                        }
                        if (popup_pen.brush === 'line') {
                            popup_pen.lineDrawing(event);
                        }
                    }else{
                        popup_pen.drawingFinish(popup_pen.brush);
                    }
                }
                break;
            case 'mouseup':
            case 'touchend':
                popup_pen.drawWrap = false;
                popup_pen.drawingFinish(popup_pen.brush);
                break;
        }
    }
};

popup_pen.initDraw = function (event, type ,color, size) {
    var self = this;


    self.ctx.lineWidth = size;
    self.ctx.lineCap = 'round';

    if(type === 'p'){
        self.save_ctx.globalAlpha = 1;
        self.canvas.style.opacity = 1;
    }else if(type === 'm'){
        self.canvas.style.opacity = 0.5;
        self.save_ctx.globalAlpha = 0.5;
    }


    self.ctx.strokeStyle = color;

    popup_pen_pos.drawable = true;

    popup_pen_pos.x = event.offsetX;
    popup_pen_pos.y = event.offsetY;

    if(event.type === 'touchstart'){
        var canvasRect = self.canvas_save.getBoundingClientRect();

        popup_pen_pos.x = (event.touches[0].clientX - canvasRect.left) / self.resizeValue;
        popup_pen_pos.y = (event.touches[0].clientY - canvasRect.top) / self.resizeValue;

    }

};

popup_pen.drawing = function (event) {
    var self = this;
    var evnt_pos = self.getPosition(event);

    self.ctx.beginPath();
    self.ctx.moveTo(popup_pen_pos.x, popup_pen_pos.y);

    self.ctx.lineTo(evnt_pos.X_1, evnt_pos.Y_1);

    self.start_x.push(popup_pen_pos.x);
    self.start_y.push(popup_pen_pos.y);
    self.end_x.push(evnt_pos.X_1);
    self.end_y.push(evnt_pos.Y_1);


    popup_pen_pos.x = evnt_pos.X_1;
    popup_pen_pos.y = evnt_pos.Y_1;

    if(evnt_pos.X_1 < 5 || evnt_pos.Y_1 < 5 || evnt_pos.X_1 > 1240 || evnt_pos.Y_1 > 823){
        popup_pen.drawWrap = false;
    }else {
        popup_pen.drawWrap = true;
    }

    self.ctx.stroke();
};

popup_pen.lineDrawing = function (event) {
    var self = this;
    var evnt_pos = self.getPosition(event);

    self.ctx.beginPath();

    // 이전꺼를 지운다
    self.ctx.clearRect( 0 , 0 , self.canvas.width , self.canvas.height);

    self.ctx.moveTo(popup_pen_pos.x, popup_pen_pos.y);
    self.ctx.lineTo(evnt_pos.X_1, evnt_pos.Y_1);


    popup_pen_temp_pos.start_x = popup_pen_pos.x;
    popup_pen_temp_pos.start_y = popup_pen_pos.y;
    popup_pen_temp_pos.end_x = evnt_pos.X_1;
    popup_pen_temp_pos.end_y = evnt_pos.Y_1;

    if(evnt_pos.X_1 < 5 || evnt_pos.Y_1 < 5 || evnt_pos.X_1 > 1240 || evnt_pos.Y_1 > 823){
        popup_pen.drawWrap = false;
    }else {
        popup_pen.drawWrap = true;
    }
    self.ctx.stroke();
    self.ctx.closePath();


};

popup_pen.drawingFinish = function (brushType) {
    var self = this;
    var tempData;

    self.ctx.clearRect( 0 , 0 , self.canvas.width , self.canvas.height);

    if(brushType === 'pen'){
        tempData = {
            'strokeColor' : self.ctx.strokeStyle,
            'alpha' : self.save_ctx.globalAlpha,
            'lineWidth' : self.ctx.lineWidth,
            'lineCap' : self.ctx.lineCap,
            'start_x' : JSON.stringify(self.start_x),
            'start_y' : JSON.stringify(self.start_y),
            'end_x' : JSON.stringify(self.end_x),
            'end_y' : JSON.stringify(self.end_y),
            'brush' : self.brush
        };
    }

    if(brushType ==='line'){
        tempData = {
            'strokeColor' : self.ctx.strokeStyle,
            'alpha' : self.save_ctx.globalAlpha,
            'lineWidth' : self.ctx.lineWidth,
            'lineCap' : self.ctx.lineCap,
            'start_x' : popup_pen_temp_pos.start_x,
            'start_y' : popup_pen_temp_pos.start_y,
            'end_x' : popup_pen_temp_pos.end_x,
            'end_y' : popup_pen_temp_pos.end_y,
            'brush' : self.brush
        };
    }

    try {
        self.savePath(tempData);
    }catch (e) {
        console.error('pen savePath error :', e);
    }

    self.viewCanvasDraw(tempData);
    self.start_x.length = 0;
    self.start_y.length = 0;
    self.end_x.length = 0;
    self.end_y.length = 0;

    popup_pen_pos.drawable = false;
    popup_pen_pos.x = -1;
    popup_pen_pos.y = -1;
};


popup_pen.getPosition = function (event) {
    var self = this;
    var x_1 = event.offsetX;
    var y_1 = event.offsetY;

    if(event.type === 'touchmove'){
        var canvasRect = self.canvas_save.getBoundingClientRect();

        x_1 = (event.touches[0].clientX - canvasRect.left) / self.resizeValue;
        y_1 = (event.touches[0].clientY - canvasRect.top) / self.resizeValue;
    }

    return {
        X_1: x_1,
        Y_1: y_1
    }
};

//그릴때마다 패스를 저장한다.
popup_pen.savePath = function (data) {
    var self = this;
    data.pageNum = VIEWER.global_value.displayPagesNum[0];
    self.pathData.push(data);
};


//그릴때마다 canvas_save로 불러온다
popup_pen.viewCanvasDraw = function (data) {
    var self = this;

    self.save_ctx.lineWidth = data.lineWidth;
    self.save_ctx.strokeStyle = data.strokeColor;
    self.save_ctx.globalAlpha = data.alpha;

    // self.save_ctx.globalAlpha = 0.5;
    self.save_ctx.lineCap = data.lineCap;

    if(data.brush ==='line'){
        self.save_ctx.beginPath();
        self.save_ctx.moveTo(data.start_x, data.start_y);

        self.save_ctx.lineTo(data.end_x, data.end_y);

        self.save_ctx.stroke();
    }

    if(data.brush === 'pen'){

        var temp_start_x  = JSON.parse(data.start_x);
        var temp_start_y  = JSON.parse(data.start_y);
        var temp_end_x  = JSON.parse(data.end_x);
        var temp_end_y  = JSON.parse(data.end_y);


        self.save_ctx.beginPath();
        self.save_ctx.moveTo(temp_start_x[0], temp_start_y[0]);


        for( var i = 1; i < data.start_x.length; i ++){
            self.save_ctx.lineTo(temp_end_x[i], temp_end_y[i]);
        }

        self.save_ctx.stroke();
        self.save_ctx.closePath();

    }

};

popup_pen.nwSaveData = function (data) {
    var self = this;
    VIEWER.storageCtrl.write(self.key, data);
};


popup_pen.nwLoadData = function () {
    var self = this;
    self.pathData = VIEWER.storageCtrl.read(self.key);

    self.save_ctx.clearRect( 0 , 0 , self.canvas_save.width , self.canvas_save.height);

    if(self.pathData){
        for(var i= 0; i < self.pathData.length; i ++){
            if(VIEWER.global_value.displayPagesNum[0] === self.pathData[i].pageNum){
                self.viewCanvasDraw(self.pathData[i]);
            }
        }
    }
};

popup_pen.deleteLayer = function () {
    var self = this;
    self.save_ctx.clearRect( 0 , 0 , self.canvas_save.width , self.canvas_save.height);
    if(self.pathData){
        self.pathData = [];
    }
};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        popup_pen.init();
    } catch (e) {
        console.error('pen init error :', e);
    }


    VIEWER.layout.layerEvent.listen('_viewerResize' , function(data){
        popup_pen.resizeValue = data.msg.scale;
        popup_pen.resizeValue = parseFloat(popup_pen.resizeValue);
    });


});




