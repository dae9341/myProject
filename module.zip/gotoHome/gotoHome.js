var gotoHome = {
    gotoHome_btn : null
};


gotoHome.init = function(){

    this.gotoHome_btn = document.querySelector('#_home button');

    this.evtBind();
};

gotoHome.evtBind = function(){
    var self = this;

    self.gotoHome_btn.addEventListener('click', function () {
        var content_directory = VIEWER.global_value.content_directory;
        var ekh = content_directory.split("/")[1];

        window.location.href = ekh + '_intro.html';
    });
};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        gotoHome.init();
    } catch (e) {
        console.error('dataRoomAdd init error :', e);
    }
});