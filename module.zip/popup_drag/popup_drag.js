var popupDrag_resizeValue = null;
var popupDrag = {
    x: 0,
    y: 0
};

popupDrag_resizeValue = document.querySelector('#viewer_wrap').style.transform.substring(28,34);
popupDrag_resizeValue = parseFloat(popupDrag_resizeValue);

VIEWER.layout.layerEvent.listen('_viewerResize' , function(data){
    popupDrag_resizeValue = data.msg.scale;
    popupDrag_resizeValue = parseFloat(popupDrag_resizeValue);
});

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {

    $('#viewer_Layer_pop').find('._popup_drag').draggable({

        handle: '._popup_drag_handle',
        containment : $('._popup_drag').parent().parent(),

        start: function(event , ui){
            $('#_drag_helper_layer').show();
            $('#viewer_wrap').css('position','fixed');
            popupDrag.x = event.clientX;
            popupDrag.y = event.clientY;
            $(this).css('transform','none');
        },
        drag:function (event, ui) {
            var original = ui.originalPosition;
            ui.position = {
                left: (event.clientX - popupDrag.x + original.left) / popupDrag_resizeValue,
                top:  (event.clientY - popupDrag.y + original.top) / popupDrag_resizeValue
            };

            var maxLeft = ui.helper[0].parentNode.parentNode.offsetWidth  - ui.helper[0].offsetWidth;
            var maxTop = ui.helper[0].parentNode.parentNode.offsetHeight  - ui.helper[0].offsetHeight;


            if(ui.position.left < 0){
                ui.position.left = 0;
            }
            if(ui.position.top < 0){
                ui.position.top = 0;
            }
            if(ui.position.top > maxTop){
                ui.position.top = maxTop;
            }
            if(ui.position.left > maxLeft){
                ui.position.left = maxLeft;
            }
        },
        stop : function(event , ui){
            var original = ui.originalPosition;
            ui.position = {
                left: (event.clientX - popupDrag.x + original.left) / popupDrag_resizeValue,
                top:  (event.clientY - popupDrag.y + original.top) / popupDrag_resizeValue
            };
            $('#_drag_helper_layer').hide();
            $('#viewer_wrap').css('position','absolute');
        }
    });

});