var bookmark = {
    key : VIEWER.global_value.content_directory + 'bookmark',
    popupLayer : null,
    btn_bookmark : null,
    btn_close : null,
    addLayer: null,
    bookMarkingLayer : null,
    flag : true,
    left_bookMark : null,
    right_bookMark : null,
    addBtn: null,
    cnt : 1
};
var bookmark_tempData = [];
var bookmarkStorage = VIEWER.storageCtrl;

bookmark.init = function () {

    var self = this;

    self.btn_bookmark = document.querySelector('#_bookmark');
    self.popupLayer = document.querySelector('#_pop_bookmark');
    self.btn_close = self.popupLayer.querySelector('._btn_bookmark_close');
    self.addLayer = document.querySelector('._pop_bookmark_contentList');
    self.bookMarkingLayer = document.querySelector('#__bookMarkLayer');
    self.left_bookMark = document.querySelector('#__left_page');
    self.right_bookMark = document.querySelector('#__right_page');
    self.addBtn = self.popupLayer.querySelector('._btn_bookmark_add');

    /*저장된 데이터 불러오기*/
    try {
        self.loadData();
    }catch (e){
        console.error('bookMark load error :' , e);
    }
    /*이벤트 처리*/
    try {
        self.bindEvent();

    }catch (e){
        console.error('bookMark bindEvent error :' , e);
    }


};

bookmark.bindEvent = function () {
    var self = this;

    self.btn_bookmark.addEventListener('click' , function () {
        self.popupLayer.classList.add('on');

        self.popupLayer.style.transform = 'translate(-50%, -50%)';
        self.popupLayer.style.left = '50%';
        self.popupLayer.style.top = '50%';
    });

    self.btn_close.addEventListener('click',function () {
        self.popupLayer.classList.remove('on');
    });

    self.addBtn.addEventListener('click',function () {
        self.addData(VIEWER.global_value.displayPagesNum[0]);
    });


};

/*저장된 데이터 불러오기*/
bookmark.loadData = function () {

    var self = this;

    if(bookmarkStorage.read(self.key)){
        bookmark_tempData = bookmarkStorage.read(self.key);

        for(var i = 0; i < bookmark_tempData.length; i ++){
            self.layerAdd(bookmark_tempData[i].page, bookmark_tempData[i].pageIndex, bookmark_tempData[i].text);
        }
    }

};

/*데이터 추가 시 레이어 생성*/
bookmark.layerAdd = function (pageNum, pageIndex, pageText) {
    var self = this;

    var addLayer_inner = document.createElement('div');
    var addLayer_page = document.createElement('span');
    var addLayer_memo = document.createElement('span');
    var addLayer_memo_textarea = document.createElement('textarea');
    var addLayer_del =  document.createElement('span');


    self.addLayer.appendChild(addLayer_inner);
    addLayer_inner.appendChild(addLayer_page);
    addLayer_inner.appendChild(addLayer_memo);
    addLayer_inner.appendChild(addLayer_del);
    addLayer_memo.appendChild(addLayer_memo_textarea);

    addLayer_inner.classList.add('__bookmark_contentWrap');
    addLayer_page.classList.add('__bookmark_contentPage');
    addLayer_memo.classList.add('__bookmark_contentMemo');
    addLayer_del.classList.add('__bookmark_contentDel');
    $(addLayer_del).append('<span class="__btn_bookMarkDelete">삭제</span>');

    addLayer_inner.setAttribute('data-index', pageIndex);


    /*삭제 클릭 (버튼 변경 필요)*/
    addLayer_del.querySelector('.__btn_bookMarkDelete').addEventListener('click',function () {
        var this_pageLayer = this.parentNode.parentNode.querySelector('.__bookmark_contentPage');
        
        /*레이어 삭제*/
        self.delete(this_pageLayer.textContent, this.parentNode.parentNode.getAttribute('data-index'));
        self.addLayer.removeChild(this.parentNode.parentNode);
    });

    /*페이지 이동*/
    $(addLayer_page).on('click',function () {
        var __thisPageNum = Number(this.textContent);
        if(__thisPageNum === VIEWER.global_value.displayPagesNum[0] || __thisPageNum === VIEWER.global_value.displayPagesNum[1]){
            alert('현재 페이지입니다.');
        }else{
            VIEWER.frameLoadCtrl.loadPage(__thisPageNum);
        }
    });

    
    /*텍스트 자동저장*/
    addLayer_memo_textarea.onchange = function () {

        var this_memoPage = this.parentNode.parentNode.querySelector('.__bookmark_contentPage').textContent;
        var this_memoIndex = this.parentNode.parentNode.getAttribute('data-index');

        for (var i = 0; i < bookmark_tempData.length; i++) {
            if (bookmark_tempData[i].page == this_memoPage && bookmark_tempData[i].pageIndex == this_memoIndex) {
                bookmark_tempData[i].text = this.value;
            }
        }
        bookmarkStorage.write(self.key, bookmark_tempData);

    };

    if(pageText){
        addLayer_memo_textarea.value = pageText;
    }else{
        addLayer_memo_textarea.value = '';
    }

    addLayer_page.innerHTML = pageNum;

};

/*storage data 추가*/
bookmark.addData = function (pageNum) {
    var self = this;
    var pageRepeatChk = true;

    var bookmark_addData = {
        'page' : pageNum,
        'pageIndex' : self.cnt,
        'text' : ''
    };

    pageIndexSet();

    /*각 page의 인덱스 세팅*/
    function pageIndexSet() {
        for(var i = 0; i < bookmark_tempData.length; i ++){
            // var indexNum = i + 1;
            if(bookmark_tempData[i].page == pageNum){
                if(bookmark_tempData[i].pageIndex >= self.cnt){
                    self.cnt = bookmark_tempData[i].pageIndex + 1;
                }
                alert('북마크 된 페이지입니다.');
                pageRepeatChk = false;
            }else {

            }

        }
    }

    if(pageRepeatChk){

        bookmark_addData.pageIndex = self.cnt;

        try {
            self.layerAdd(pageNum, bookmark_addData.pageIndex);
        }catch (e){
            console.error('북마크 add시 layerAdd error :' , e);
        }

        self.cnt = 1;


        bookmark_tempData.push(bookmark_addData);


        if(!pageNum){
            return false;
        }

        bookmarkStorage.write(self.key, bookmark_tempData);

    }
};

/*storage data 삭제*/
bookmark.delete = function (pageNum, pageIndex) {
    var self = this;
    var deleteArray_num = null;

    for(var i = 0; i < bookmark_tempData.length; i++){
        if(bookmark_tempData[i].page == pageNum && bookmark_tempData[i].pageIndex == pageIndex){
            deleteArray_num = i;
        }
    }

    /*tempData에서 해당 index를 삭제해주고 localStorage 재세팅*/
    bookmark_tempData.splice(deleteArray_num, 1);
    bookmarkStorage.write(self.key, bookmark_tempData);
};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        bookmark.init();
    } catch (e) {
        console.error('bookMark init error :', e);
    }
});