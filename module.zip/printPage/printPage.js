var printPage = {
    btn_print : null
};

printPage.init = function () {
    var self = this;

    self.btn_print = document.querySelector('#_print');

    try {
        self.bindEvent();

    }catch (e){
        console.error('print bindEvent error :' , e);
    }
};

printPage.bindEvent = function () {

    var self = this;

    self.btn_print.addEventListener('click' , function () {
        //pc
        if(!VIEWER.basic.isMOBILE() == true && !VIEWER.basic.isNW() == true){

            // printCtrl.init();
            window.print();

        } else if(VIEWER.basic.isNW() == true){ //nw
            printCtrl.init();
        } else{ //mobile
            alert('인쇄 기능 지원하지 않습니다.')
        }

    });

};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        printPage.init();
    } catch (e) {
        console.error('print init error :', e);
    }
});








/**
 * Created by JongMin on 2017-12-28.
 */

var printCtrl = {
    printerList : [],
    NW_win : null,
    dimLayer : null,
    printUI_Layer : null,
    selectPrinter : null,
    thumImgPath : null,
    onePageViewLayer : null,
    twoPageViewLayer : null,
    pageSet_All_radio : null,
    pageSet_Range_radio : null,
    pageSet_current_radio : null ,
    printingIMG : [] ,
    eventSet : false ,
    selectPrinterName : null ,
    selectPrinterList : null ,
    maxPageNum : null ,
    minPageNum : null ,
    landscape_true : null ,
    landscape_false : null ,
    printFirstPageNum : null,
    printLastPageNum : null ,
    error_msg_Layer : null
};

printCtrl.init = function(){
    var self = this;

    self.NW_win = nw.Window.get();
    self.dimLayer = document.querySelector('.__dimLayer');
    self.printUI_Layer = document.getElementById('printLayer');
    self.thumImgPath = VIEWER.global_value.content_directory + 'print_img/';
    self.printerList = [];




    self.maxPageNum = VIEWER.global_value.lastPageNum;
    self.minPageNum = VIEWER.global_value.startPageNum;

    //가로 세로 인풋
    self.landscape_true = document.getElementById('landscape_true');
    self.landscape_false = document.getElementById('landscape_false');

    self.printFirstPageNum = document.getElementById('printFirstPageNum');
    self.printLastPageNum = document.getElementById('printLastPageNum');

    //에러 메세지 창
    self.error_msg_Layer = document.getElementById('_error_print_msg');

    self.NW_win.getPrinters(function(list){
        //사용할수 있는 프린터 선택
        list.forEach(function(o){
            if(!o.deviceName.match(/FAX|PDF|XPS /gi)){
                self.printerList.push(o);
            }
        });

        self.ui_set();
    });

};

printCtrl.ui_set = function(){

    var self = this;

    if(self.printerList.length < 1) {
        alert('사용할 수 있는 프린터가 없습니다.');
        return false;
    }

    self.onePageViewLayer = document.getElementById('a4_set_layer_v');
    self.twoPageViewLayer = document.getElementById('a4_set_layer_h');

    //라디오 테그 등록
    self.pageSet_All_radio = document.getElementById('pageSet_All');
    self.pageSet_Range_radio = document.getElementById('pageSet_Range');
    self.pageSet_current_radio = document.getElementById('pageSet_current');

    //프린터 리스트 등록
    self.selectPrinterName = self.printUI_Layer.querySelector('.set_printer_name');
    self.selectPrinterList = self.printUI_Layer.querySelector('.printer_list');

    self.selectPrinterList.innerHTML = ' ';

    var appendHtml = '';
    self.printerList.forEach(function(o){
        appendHtml += '<li data-value="' + o.printerName + '">' + o.printerName + '</li>'
    });

    //초기화
    self.selectPrinterList.innerHTML = appendHtml;
    self.selectPrinterName.innerHTML = self.printerList[0].printerName;
    self.selectPrinterName.setAttribute('data-value' , self.printerList[0].printerName);

    //페이지 인쇄 영역 초기 셋
    self.pageSet_current_radio.checked = true;


    if(VIEWER.global_value.displayPage < 2){
        self.landscape_false.checked = true;
    } else {
        self.landscape_true.checked = true;
    }

    //미리보기 셋팅
    self.preViewImgAdd();

    self.dimLayer.style.display = 'block';
    self.printUI_Layer.style.display = 'block';

    if(!self.eventSet){
        self.bindEvt();
    }

    setTimeout(function(){
        self.bindEvt_allWays();
    },10);

};

//미리보기 이미지 등록
//가로 세로 셋팅, 페이지 리스트
printCtrl.preViewImgAdd = function(){

    var self = this;
    var pageList = self.getPageList();
    var appendLayer = null;
    var appendHtml = '';

    self.error_msg_Layer.innerHTML = '';

    if(typeof pageList == 'string') {
        self.error_msg_Layer.innerHTML = '※ ' + pageList;
        return false;
    }

    //가로
    if(self.landscape_true.checked){

        self.onePageViewLayer.style.display = 'none';
        self.twoPageViewLayer.style.display = 'block';
        appendLayer = self.twoPageViewLayer;

        appendLayer.innerHTML = '';

        pageList.forEach(function(o,i){
            if(i != pageList.length - 1){
                if(i % 2 != 0){
                    appendHtml += '<img src="'+self.thumImgPath + 'print_page'+ self.leadingZeros(o , 3) +'.jpg'+'"/>';
                    appendHtml += '</div>';
                }else{
                    appendHtml += '<div>';
                    appendHtml += '<img src="'+self.thumImgPath + 'print_page'+ self.leadingZeros(o , 3) +'.jpg'+'"/>';
                }
            }else{
                if(i % 2 == 0){
                    appendHtml += '<div>';
                }
                appendHtml += '<img src="'+self.thumImgPath + 'print_page'+ self.leadingZeros(o , 3) +'.jpg'+'"/>';
                appendHtml += '</div>';
            }
        });
    } else {

        self.onePageViewLayer.style.display = 'block';
        self.twoPageViewLayer.style.display = 'none';
        appendLayer = self.onePageViewLayer;

        appendLayer.innerHTML = '';

        pageList.forEach(function(o){
            appendHtml += '<div>';
            appendHtml += '<img src="'+self.thumImgPath + 'print_page'+ self.leadingZeros(o , 3) +'.jpg'+'"/>';
            appendHtml += '</div>';
        });
    }

    appendLayer.innerHTML = appendHtml;
};

//한번 등록 이벤트
printCtrl.bindEvt = function(){

    var self = this;
    var printBtn = document.getElementById('__print_start');
    var printCancelBtn = document.getElementById('__print_cancel');

    self.eventSet = true;

    printBtn.addEventListener('click' , function(){
        //인쇄를 해야되는 페이지를 가져온다.
        var printPagesList = printCtrl.getPageList();

        //이미지를 영역에 만들어 준다.
        printCtrl.hiddenImgSet(printPagesList , function(){
            //콜백 프린터 시작
            self.API_start();
        });
    });

    printCancelBtn.addEventListener('click' , function(){
        document.getElementById('pageSet_Range_value').value = '';
        self.dimLayer.style.display = 'none';
        self.printUI_Layer.style.display = 'none';
        self.selectPrinterList.style.display = 'none';
        self.selectPrinterName.classList.remove('on');
    });

    //프린터 선택
    self.selectPrinterName.addEventListener('click' , function(){
        if(this.classList.contains('on')){
            this.classList.remove('on');
            self.selectPrinterList.style.display = 'none';
        } else {
            this.classList.add('on');
            self.selectPrinterList.style.display = 'block';
        }
    });

    //가로 세로 셋
    self.landscape_true.addEventListener('click' , function(){
        self.preViewImgAdd();
    });
    self.landscape_false.addEventListener('click' , function(){
        self.preViewImgAdd();
    });

    //현재 페이지
    self.pageSet_Range_radio.addEventListener('click' , function(){
        self.preViewImgAdd();
    });

    //일부분
    self.pageSet_current_radio.addEventListener('click' , function(){
        self.preViewImgAdd();
    });

    document.getElementById('pageSet_Range_value').addEventListener('keyup' , function(){
        self.preViewImgAdd();
    });

};

//인쇄를 해야할 페이지의 리스트를 만들어 준다.
printCtrl.getPageList = function(){

    var self = this;

    var startPageNum = VIEWER.global_value.startPageNum;

    //전체 페이지
    if(self.pageSet_All_radio.checked){
        var returnData = [];
        for(var i = 0;  self.maxPageNum >= i; i++){
            returnData.push(i);
        }
        return returnData;
    }

    //범위
    if(self.pageSet_Range_radio.checked){

        var rangeValue = document.getElementById('pageSet_Range_value');
        var returnData = [];


        try {
            var pageArray = rangeValue.value.split(',');

            for(var i = 0; pageArray.length > i; i++){
                if(isNaN(pageArray[i].trim())){
                    if(pageArray[i].trim().match('-').length > 0){
                        var rangeSet = pageArray[i].trim().split('-');

                        for(var index = Number(rangeSet[0]); Number(rangeSet[1]) >= index; index++ ){
                            if(startPageNum > index || self.maxPageNum + startPageNum + 1 < index){
                                return '서책의 범위를 확인해 주세요.';
                            }
                            returnData.push(index);
                        }
                    } else {
                        rangeValue.value = '';
                        return '예를 확인하시고 범위를 지정해 주십시오.';
                    }
                } else {
                    if(startPageNum > Number(pageArray[i]) || self.maxPageNum + startPageNum < Number(pageArray[i])){
                        return '서책의 범위를 확인해 주세요.';
                    }
                    returnData.push(pageArray[i].trim());
                }
            }
        } catch(e) {
            rangeValue.value = '';
            alert('예를 확인하시고 범위를 지정해 주십시오.');
        }
        return returnData;
    }

    //현재 페이지
    if(self.pageSet_current_radio.checked){
        if(VIEWER.global_value.displayPage < 2){
            return VIEWER.global_value.displayPagesNum;
        } else {
            return VIEWER.global_value.displayPagesNum;
        }
    }

    return [];
};

//항상 등록시켜줘야 하는 이벤트
printCtrl.bindEvt_allWays = function(){


    var self = this;
    var printerSelectList = self.selectPrinterList.querySelectorAll('li');


    printerSelectList.forEach(function(o){
        o.addEventListener('click' , function(){
            var deviceName = this.getAttribute('data-value');
            self.selectPrinterList.style.display = 'none';
            self.selectPrinterName.innerHTML = deviceName;
            self.selectPrinterName.classList.remove('on');
            self.selectPrinterName.setAttribute('data-value' , deviceName);
        });
    });


};

//프린터를 위한 안보이는 이미지 셋
printCtrl.hiddenImgSet = function(pageList , callBack){

    if(!pageList) return false;
    if(pageList.length < 1) return false;

    var self = this;
    var hiddenPrintWrap = document.getElementById('__hidden_printPageWrap');
    hiddenPrintWrap.innerHTML = '';

    var appendHtml = '';

    if(self.landscape_false.checked == true){
        pageList.forEach(function(o){
            appendHtml += '<div style="position:relative; width:100%; height:100%;">';
            appendHtml += '<img src="'+ self.thumImgPath +'print_page'+ self.leadingZeros(o , 3) +'.jpg" style="height:100%; position: absolute; top: 50%; left: 50%; transform: translate(-50% , -50%);" />';
            appendHtml += '</div>';
        });
    } else {
        pageList.forEach(function(o){
            if(o%2 != 0){
                appendHtml += '<div style="position: relative; width: 100%; height: 100%;">';
                appendHtml += '<img src="'+ self.thumImgPath +'print_page'+ self.leadingZeros(o , 3) +'.jpg" style="width:50%; position: absolute; top: 50%; left: 50%; transform: translate(-100% , -50%);" />';
            } else {
                appendHtml += '<img src="'+ self.thumImgPath +'print_page'+ self.leadingZeros(o , 3) +'.jpg" style="width:50%; position: absolute; top: 50%; left: 50%; transform: translate(0 , -50%);" />';
                appendHtml += '</div>';
            }
        });
    }

    hiddenPrintWrap.innerHTML = appendHtml;

    //로드 대신 우선 타이머로 처리
    setTimeout(function(){
        if(callBack) callBack();
    },500);
};

//프린터 api 스타트
printCtrl.API_start = function(){

    var self = this;
    var printOption = {};

    document.getElementById('pageSet_Range_value').value = '';
    self.dimLayer.style.display = 'none';
    self.printUI_Layer.style.display = 'none';
    self.selectPrinterList.style.display = 'none';
    self.selectPrinterName.classList.remove('on');

    printOption.headerFooterEnabled = false;
    printOption.printer = self.selectPrinterName;

    if( self.landscape_true.checked == true ){
        printOption.landscape = true;
    } else {
        printOption.landscape = false;
    }

    self.NW_win.print(printOption);
};

//자릿수 마추어 주기
printCtrl.leadingZeros = function(n, digits){
    var zero = '';
    n = n.toString();

    if (n.length < digits) {
        for (var i = 0; i < digits - n.length; i++)
            zero += '0';
    }
    return zero + n;
};



