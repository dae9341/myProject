var list = {
    popupLayer : null,
    btn_list : null,
    btn_close : null,
    listLayer : null,
    cnt : null,
    dep_3_num : 1 ,
    list_tempData : null
};


list.init = function () {
    var self = this;

    self.btn_list = document.querySelector('#_list');
    self.popupLayer = document.querySelector('#_pop_list');
    self.btn_close = self.popupLayer.querySelector('._btn_list_close');
    self.listLayer = self.popupLayer.querySelector('#_pop_list_content');

    try {
        self.listMake();
    }catch (e){
        console.error('list listMake error :' , e);
    }
    try {
        self.bindEvent();
    }catch (e){
        console.error('list bindEvent error :' , e);
    }

};

list.bindEvent = function () {

    var self = this;

    self.btn_list.addEventListener('click' , function () {
        self.popupLayer.classList.add('on');
        self.popupLayer.style.transform = 'translate(-50%, -50%)';
        self.popupLayer.style.left = '50%';
        self.popupLayer.style.top = '50%';
    });

    self.btn_close.addEventListener('click',function () {
        self.popupLayer.classList.remove('on');
        $('.list_dep_1_btn').removeClass('on');
        $('.list_dep_2_btn').removeClass('on');
        $('.list_dep_2').removeClass('on');
        $('.list_dep_3').removeClass('on');
    });

    $('.list_dep_1_btn').on('click', function () {
        var btnStatus = $(this).hasClass('on');
        var num = $(this).parent('.list_dep_1').index();

        if(!btnStatus){
            $(this).addClass('on');
            $(this).parents('#_pop_list_content').children('div').eq(num+1).addClass('on');
        }else{
            $(this).removeClass('on');
            $(this).parents('#_pop_list_content').children('div').eq(num+1).removeClass('on');
        }

    });

    $('.list_dep_2_btn').on('click', function () {
        var btnStatus = $(this).hasClass('on');

        if(!btnStatus){
            $(this).addClass('on');
            $(this).siblings('.list_dep_3').addClass('on');
        }else{
            $(this).removeClass('on');
            $(this).siblings('.list_dep_3').removeClass('on');
        }
    });

    $('#_pop_list_content .list_dep_1 span').on('click', function () {
        var __pageNumber = Number($(this).attr('data-pagenum'));

        if(__pageNumber === VIEWER.global_value.displayPagesNum[0] || __pageNumber === VIEWER.global_value.displayPagesNum[1]){
            alert('현재 페이지입니다.');
        }else {
            VIEWER.frameLoadCtrl.loadPage(__pageNumber);
        }


    });

    $('#_pop_list_content .list_dep_2 div span').on('click', function () {
        var __pageNumber = Number($(this).attr('data-pagenum'));

        if(__pageNumber === VIEWER.global_value.displayPagesNum[0] || __pageNumber === VIEWER.global_value.displayPagesNum[1]){
            alert('현재 페이지입니다.');
        }else {
            VIEWER.frameLoadCtrl.loadPage(__pageNumber);
        }
    });

    $('#_pop_list_content .list_dep_2 div.__depth_3 .list_dep_3 p').on('click', function () {
        var __pageNumber = Number($(this).attr('data-pagenum'));

        if(__pageNumber === VIEWER.global_value.displayPagesNum[0] || __pageNumber === VIEWER.global_value.displayPagesNum[1]){
            alert('현재 페이지입니다.');
        }else {
            VIEWER.frameLoadCtrl.loadPage(__pageNumber);
        }
    });
};

list.listMake = function (){

    var self = this;
    var cntNum;

    self.depthMaker(3);
    //1depth
    for( var i = 0; i < self.list_tempData.length; i ++){

        if(self.list_tempData[i].dep  == 1){
            $(self.listLayer).append('<div class="list_dep_1"><button type="button" class="list_dep_1_btn"></button><span data-pagenum="' + VIEWER.searchText.fileToPageNum(self.list_tempData[i].path)  +'">' + self.list_tempData[i].title + '</span></div>');
            cntNum = self.list_tempData[i].listBinderNum;

            $(self.listLayer).append('<div class="list_dep_2"></div>');


            //2depth
            for( var j = 0; j < self.list_tempData.length; j ++ ){
                if(self.list_tempData[j].dep  == 2 && self.list_tempData[j].listBinderNum == cntNum){
                    if(self.list_tempData[j+1] && self.list_tempData[j+1].dep == 3){

                        $(self.listLayer).find('.list_dep_2').eq(cntNum - 1).append('<div class="__depth_3"> <button type="button" class="list_dep_2_btn"></button><span data-pagenum=" ' + VIEWER.searchText.fileToPageNum(self.list_tempData[j].path) + ' ">' + self.list_tempData[j].title + ' (p.' + VIEWER.searchText.fileToPageNum(self.list_tempData[j].path) + ')' + '</span><div class="list_dep_3" data-num="' + self.dep_3_num + '"></div></div>');

                        for( var k = 0; k < self.list_tempData.length; k ++){
                            if(self.list_tempData[k].dep  == 3 && self.list_tempData[k].dep_3_chk == self.dep_3_num ){
                                $('.list_dep_3').eq(self.dep_3_num - 1).append('<p data-pagenum=" ' + VIEWER.searchText.fileToPageNum(self.list_tempData[k].path) + ' ">' + self.list_tempData[k].title + ' (p.' + VIEWER.searchText.fileToPageNum(self.list_tempData[k].path) + ')' + '</p>');
                            }
                        }
                        self.dep_3_num ++;

                    }else{
                        if(self.list_tempData[j].goToPage){
                            $(self.listLayer).find('.list_dep_2').eq(cntNum - 1).append('<div><span data-pagenum=" ' + VIEWER.searchText.fileToPageNum(self.list_tempData[j].goToPage) + ' ">' + self.list_tempData[j].title + ' (p.' + VIEWER.searchText.fileToPageNum(self.list_tempData[j].goToPage) + ')' +'</span></div>');
                        }else{
                           $(self.listLayer).find('.list_dep_2').eq(cntNum - 1).append('<div><span data-pagenum=" ' + VIEWER.searchText.fileToPageNum(self.list_tempData[j].path) + ' ">' + self.list_tempData[j].title + ' (p.' + VIEWER.searchText.fileToPageNum(self.list_tempData[j].path) + ')' +'</span></div>');
                        }
                    }

                }


            }
        }
    }

};


list.depthMaker = function (a) {
    var self = this;
    var dep3_num = 1;
    self.cnt = 0;

    self.list_tempData = VIEWER.basic.getPageList(a);

    for(var i = 0; i < self.list_tempData.length; i ++){
        if(self.list_tempData[i].dep == 1){
            self.cnt ++;
        }
        self.list_tempData[i].listBinderNum = self.cnt;
    }
    
    for(var i = 0; i < self.list_tempData.length; i ++){
        if(self.list_tempData[i].dep == 3){
            self.list_tempData[i].dep_3_chk = dep3_num;
            dep3_num++;
        }
    }

};



VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        list.init();
    } catch (e) {
        console.error('list init error :', e);
    }
});




