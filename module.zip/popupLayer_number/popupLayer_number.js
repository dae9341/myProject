var popup_number = {
    popup_dimLayer :null,
    popupLayer : null,
    btn_number : null,
    btn_close : null,
    btn_numberChk : null,
    input_number : null,
    numberLayer_default : null,
    numberLayer_active : null,
    _number_start : null,
    _number_reset : null,
    number_arr : new Array()
};

popup_number.init = function () {
    var self = this;

    self.popup_dimLayer = document.querySelector('#_popupLayer_layer');
    self.btn_number = document.querySelector('#_popupLayer_number');
    self.popupLayer = document.querySelector('#_numberLayer');
    self.btn_close = self.popupLayer.querySelector('._popupLayer_layer_close');
    self.btn_numberChk = self.popupLayer.querySelector('._number_chk');
    self.input_number = self.popupLayer.querySelector('._number_in');
    self.numberLayer_default = self.popupLayer.querySelector('._numberLayer_default');
    self.numberLayer_active = self.popupLayer.querySelector('._numberLayer_active');
    self._number_start = self.popupLayer.querySelector('._number_start');
    self._number_reset = self.popupLayer.querySelector('._number_reset');

    try {
        self.bindEvent();
    }catch (e){
        console.error('timer bindEvent error :' , e);
    }
};

popup_number.bindEvent = function () {
    var self = this;

    self.btn_number.addEventListener('click', function () {
        self.popupLayer.classList.add('on');
        self.popup_dimLayer.classList.add('on');
    });

    self.btn_close.addEventListener('click', function () {
        self.popupLayer.classList.remove('on');
        self.popup_dimLayer.classList.remove('on');
        self.resetNumberSelect();
    });

    self.btn_numberChk.addEventListener('click', function () {
        var input_val = self.input_number.value;
        input_val = Number(input_val);
        if(input_val > 0 && input_val < 61 ){
            self.numberLayer_default.classList.remove('on');
            self.numberLayer_active.classList.add('on');
            self.numberLayerSet(input_val);
        }else {
            alert('1~60사이의 숫자를 입력하세요');
        }
    });

    self._number_start.addEventListener('click' , function () {

        if(self.number_arr.length > 0){
            $(self.numberLayer_active).find('._number').remove();
            self.startNumberSelect();
        }
    });

    self._number_reset.addEventListener('click' , function () {
        self.resetNumberSelect();
    })
};

popup_number.numberLayerSet = function (value) {
    var self = this;

    for(var i = 1; i <= value; i ++){
        if(i < 10){
            $(self.numberLayer_active).find('._number_list').append('<li class="Nanum">' + '0' + i + '</li>');
        }else{
            $(self.numberLayer_active).find('._number_list').append('<li class="Nanum">' + i + '</li>');
        }
        self.number_arr.push(i);
    }

};

popup_number.startNumberSelect = function () {
    var self = this;

    shuffle(self.number_arr);

    var selectNum = self.number_arr[self.number_arr.length-1];

    //선택된 번호 체크
    $(self.numberLayer_active).find('._number_list').find('li').eq(selectNum - 1).addClass('on');

    $(self.numberLayer_active).append('<div class="_number Nanum on"><div>' + $(self.numberLayer_active).find('._number_list').find('li').eq(selectNum - 1).text() + '</div></div>');
    self.number_arr.pop();


    function shuffle(a) {
        var tempData;
        for (var i = a.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));

            tempData = a[i];
            a[i] = a[j];
            a[j] = tempData;

        }
        return a;
    }

};

popup_number.resetNumberSelect = function () {
    var self = this;

    self.numberLayer_default.classList.add('on');
    self.numberLayer_active.classList.remove('on');
    $(self.numberLayer_active).find('._number_list li').remove();
    $(self.numberLayer_active).find('._number').removeClass('on');
    self.input_number.value = '00';
    self.number_arr.length = 0;

};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        popup_number.init();
    } catch (e) {
        console.error('timer init error :', e);
    }
});


