var searchData = {
    popupLayer : null,
    btn_search : null,
    btn_close : null,
    popupLayer_content: null,
    inputBox_content: null,
    btn_search_content : null,
    search_data : null,
    popupLayer_footer : null,
    searchDataArr : null
};


searchData.init = function () {
    var self = this;

    self.btn_search = document.querySelector('#_search');
    self.popupLayer = document.querySelector('#_pop_search');
    self.btn_close = self.popupLayer.querySelector('._btn_search_close');
    self.popupLayer_content = document.querySelector('#_pop_search_content');
    self.inputBox_content = self.popupLayer_content.querySelector('._search_txt');
    self.btn_search_content = self.popupLayer_content.querySelector('._btn_search_content');
    self.popupLayer_footer = document.querySelector('#_pop_search_footer');

    try {
        self.bindEvent();
    }catch (e){
        console.error('search bindEvent error :' , e);
    }

};

searchData.bindEvent = function () {

    var self = this;

    self.btn_search.addEventListener('click' , function () {
        self.popupLayer.classList.add('on');
        self.popupLayer.style.transform = 'translate(-50%, -50%)';
        self.popupLayer.style.left = '50%';
        self.popupLayer.style.top = '50%';
    });

    self.btn_close.addEventListener('click',function () {
        self.popupLayer.classList.remove('on');
        $(self.popupLayer_content.querySelector('._search_txt')).val('');

        try{
            self.resetLayer();
        }catch (e){
            console.error('search resetLayer error :' , e);
        }
    });

    self.inputBox_content.onchange = function () {
      self.search_data = this.value;
    };

    self.btn_search_content.addEventListener('click', function () {
       //input값으로 검색기능 작동
       self.searchDataArr = VIEWER.searchText.search(self.search_data);

       if(self.searchDataArr.length === 0){
           alert('검색 데이터가 없습니다.');
       }else{
           try{
               self.resetLayer();
           }catch (e){
               console.error('search resetLayer error :' , e);
           }

           try {
               self.layerAdd(self.searchDataArr.length);
           }catch (e){
               console.error('search add Layer error :' , e);
           }

           try {
               self.layerAdd_content();
           }catch (e){
               console.error('search add content error :' , e);
           }

           self.footerLayerAdd(self.searchDataArr.length);
       }


    });

};

//ul, li를 데이터 length에 맞게 생성한다.
searchData.layerAdd = function ( count ) {

    var self = this;

    var search_list = self.popupLayer_content.querySelector('._search_list');

    var ul_count , li_count;

    if(count % 5 == 0 ){
        ul_count = Math.floor(count / 5) ;
    }else{
        ul_count = Math.floor(count / 5) + 1;
    }

    for(var i = 0; i < ul_count; i ++){
        $(search_list).append('<ul class="__search_list_1depth" ></ul>');
    }

    var uls_1depth = search_list.querySelectorAll('.__search_list_1depth');
    uls_1depth[0].classList.add('on');

    for(var i = 0; i < uls_1depth.length; i ++) {
        li_count = 5;

        if(i == uls_1depth.length - 1 && count % 5 != 0){
            li_count = count % 5;
        }

        for(var j = 0 ; j < li_count; j++) {
            $(uls_1depth[i]).append('<li class="__search_list_2depth"></li>');
        }
    }



    //페이지 이동
    $('.__search_list_2depth').on('click' , function () {
        var searchPageNum = Number($(this).find('.__search_data_pageNum').attr('data-searchpagenum'));
        if(searchPageNum === VIEWER.global_value.displayPagesNum[0] || searchPageNum === VIEWER.global_value.displayPagesNum[1]){
            alert('현재 페이지입니다.');
        }else{
            VIEWER.frameLoadCtrl.loadPage(searchPageNum);
        }
    });

};

// li태그 내부에 페이지정보, 검색내용 레이어 생성한다.
searchData.layerAdd_content = function () {
    var self = this;

    var contentLayer = self.popupLayer_content.querySelectorAll('.__search_list_2depth');

    for(var i = 0; i < contentLayer.length; i ++){
        $(contentLayer[i]).append('<img src="' + self.searchDataArr[i].img + '" />');
        $(contentLayer[i]).append('<div class="__search_data"><p class="__search_page">PAGE:<span class="__search_data_pageNum" data-searchPageNum = "' + self.searchDataArr[i].pageNum + '">' + self.searchDataArr[i].pageNum + '</span></p> <div class="__search_data_content">' + self.searchDataArr[i].dom_str + '</div></div>')
    }

};

//숫자 버튼 생성한다.
searchData.footerLayerAdd = function (count) {
    var self = this;
    var footer_num;

    if(count % 5 == 0 ){
        footer_num = Math.floor(count / 5) ;
    }else{
        footer_num = Math.floor(count / 5) + 1;
    }

    var footer_num_length = Math.floor(footer_num / 10);

    for(var j = 0; j <= footer_num_length; j++){
        if(j===0){
            $(self.popupLayer_footer).append('<div class="__search_footer_numLayer on"></div>');
        }else{
            $(self.popupLayer_footer).append('<div class="__search_footer_numLayer"></div>');
        }
    }
    for(var i = 0; i < footer_num; i++){
        var lengthChk = Math.floor(i / 10);
        $($(self.popupLayer_footer).find('.__search_footer_numLayer').eq(lengthChk)).append('<button type="button" class="__search_footer_numBtn">' + (i + 1) + '</button>')
    }

    try{
        footerNumBtnFunc();
    } catch (e){
        console.error('search footerNumBtnFunc error :' , e);
    }

    function footerNumBtnFunc() {
        var __search_list_1depth = self.popupLayer_content.querySelectorAll('.__search_list_1depth');
        var __search_footer_numBtn = self.popupLayer_footer.querySelectorAll('.__search_footer_numBtn');
        __search_footer_numBtn[0].classList.add('on');

        for(var i = 0; i < __search_footer_numBtn.length; i ++){
            __search_footer_numBtn[i].addEventListener('click', function () {
                $(__search_footer_numBtn).removeClass('on');
                $(this).addClass('on');
                $(__search_list_1depth).removeClass('on');

                var __1depth_showNum = $(this).text() - 1;
                $(__search_list_1depth[__1depth_showNum]).addClass('on');
            });
        }
    }

    if(lengthChk > 0){
        self.footerLayerArrange();
    }
};

//검색결과 footer 레이어 생성
searchData.footerLayerArrange = function () {
    var self = this;
    var __searchNumBtn  = $(self.popupLayer_footer).find('.__search_footer_numLayer');
    for( var i = 0; i < __searchNumBtn.length; i ++ ){
        __searchNumBtn.eq(i).append('<button type="button" class="__search_leftBtn"></button> <button type="button" class="__search_rightBtn"></button>')
    }

    $('.__search_rightBtn').on('click', function () {
        var onLayer_index = $('#_pop_search_footer').find('.__search_footer_numLayer.on').index();

        if($('#_pop_search_footer').find('.__search_footer_numLayer').length > onLayer_index + 1){
            $('#_pop_search_footer').find('.__search_footer_numLayer').removeClass('on');
            $('#_pop_search_footer').find('.__search_footer_numBtn').removeClass('on');

            $('#_pop_search_footer').find('.__search_footer_numLayer').eq(onLayer_index + 1).addClass('on');
            $('#_pop_search_footer').find('.__search_footer_numLayer').eq(onLayer_index + 1).find('.__search_footer_numBtn').eq(0).addClass('on');

            $('#_pop_search_content ._search_list').find('.__search_list_1depth').removeClass('on');
            $('#_pop_search_content ._search_list').find('.__search_list_1depth').eq((onLayer_index + 1) * 10).addClass('on');
        }else{
            alert('마지막 페이지입니다.');
        }
    });

    $('.__search_leftBtn').on('click', function () {
        var onLayer_index = $('#_pop_search_footer').find('.__search_footer_numLayer.on').index();

        if(onLayer_index - 1 >= 0){
            $('#_pop_search_footer').find('.__search_footer_numLayer').removeClass('on');
            $('#_pop_search_footer').find('.__search_footer_numBtn').removeClass('on');

            $('#_pop_search_footer').find('.__search_footer_numLayer').eq(onLayer_index - 1).addClass('on');
            $('#_pop_search_footer').find('.__search_footer_numLayer').eq(onLayer_index - 1).find('.__search_footer_numBtn').eq(0).addClass('on');

            $('#_pop_search_content ._search_list').find('.__search_list_1depth').removeClass('on');
            $('#_pop_search_content ._search_list').find('.__search_list_1depth').eq((onLayer_index - 1) * 10).addClass('on');
        }else{
            alert('첫 페이지입니다.');
        }
    });
};

searchData.resetLayer = function () {
    var self = this;
    var __search_list_1depth = self.popupLayer_content.querySelectorAll('.__search_list_1depth');
    var __search_footer_numLayer = self.popupLayer_footer.querySelectorAll('.__search_footer_numLayer');
    $(__search_list_1depth).remove();
    $(__search_footer_numLayer).remove();

};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        searchData.init();
    } catch (e) {
        console.error('search init error :', e);
    }
});




