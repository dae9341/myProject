var pen = {
    key : 'pen',
    viewer : null,
    popupLayer : null,
    btn_pen : null,
    btn_close : null,
    canvasWrap : null,
    canvas : null,
    canvas_save : null,
    ctx : null,
    color : '#000',
    type : 'p' ,
    brush : 'pen' ,
    size : 4,
    eraser_1 : null,
    eraser_2 : null,
    mouseEvent : true,
    pathData : new Array(),
    eraser_undo : null,
    save_ctx : null,
    start_x : new Array(),
    start_y : new Array(),
    end_x : new Array(),
    end_y : new Array(),
    resizeValue : null,
    drawWrap : false
};

var pos = {
    drawable : false,
    x: -1,
    y: -1
};

var temp_pos ={
        start_x:'',
        start_y:'',
        end_x:'',
        end_y:''
};




pen.init = function () {
    var self = this;
    self.viewer = document.querySelector('#viewer_wrap');

    self.btn_pen = document.querySelector('#_pen');
    self.popupLayer = document.querySelector('#_pop_pen');
    self.btn_close = document.querySelector('._btn_pen_close');
    self.eraser_1 = self.popupLayer.querySelector('._eraser1');
    self.eraser_2 = self.popupLayer.querySelector('._eraser2');
    self.eraser_undo = self.popupLayer.querySelector('._eraser3');

    self.canvasWrap = document.querySelector('#_canvas_container');
    self.canvas = document.querySelector('#__pen_canvas');
    self.canvas_save = document.querySelector('#__pen_canvas_save');

    self.ctx = self.canvas.getContext("2d");
    self.save_ctx = self.canvas_save.getContext("2d");


    self.canvas.setAttribute('width' , VIEWER.global_value.frameLayout.width);
    self.canvas.setAttribute('height' , VIEWER.global_value.frameLayout.height);
    self.canvas_save.setAttribute('width' , VIEWER.global_value.frameLayout.width);
    self.canvas_save.setAttribute('height' , VIEWER.global_value.frameLayout.height);


    self.resizeValue = parseFloat(document.querySelector('#viewer_wrap').style.transform.substring(28,34));

    try {
        self.bindEvent();
    }catch (e){
        console.error('pen bindEvent error :' , e);
    }


};




pen.bindEvent = function () {

    var self = this;

    self.btn_pen.addEventListener('click' , function () {
        self.popupLayer.classList.add('on');
        self.popupLayer.style.left = '50%';
        self.popupLayer.style.top = 'auto';
        self.popupLayer.style.transform = 'translateX(-50%)';
        self.canvasWrap.style.display = 'block';
        self.canvas.style.pointerEvents = 'auto';
        self.canvas_save.style.pointerEvents = 'auto';
        self.mouseEvent = true;
    });

    self.btn_close.addEventListener('click',function () {
        self.popupLayer.classList.remove('on');
        self.canvas.classList.remove('on');
        self.canvas.style.pointerEvents = 'none';
        self.canvas_save.style.pointerEvents = 'none';
        self.mouseEvent = false;
    });

    self.eraser_1.addEventListener('click', function () {
        self.save_ctx.clearRect( 0 , 0 , self.canvas.width , self.canvas.height);

        if(VIEWER.basic.isNW() === true){

            for(var i = 0; i < self.pathData.length; i++ ){
                if(self.pathData[i].pageNum === VIEWER.global_value.displayPagesNum[0]){
                    self.pathData.splice(i,1);
                    i --;
                }
            }
            try {
                self.nwSaveData(self.pathData);
            } catch (e){
                console.error('pen nw save data error :', e);
            }
        }else{
            self.pathData.length = 0;
        }

    });

    self.eraser_2.addEventListener('click', function () {
        var btnStatus = this.classList.contains('on');
        if(!btnStatus){
            self.canvas.style.display = 'none';
            self.canvas_save.style.display = 'none';
            this.classList.add('on');
            this.textContent = 'Show';
        }else{
            self.canvas.style.display = 'block';
            self.canvas_save.style.display = 'block';
            this.classList.remove('on');
            this.textContent = 'Hide';
        }
    });

    self.eraser_undo.addEventListener('click', function () {
        self.pathData.pop();
        self.save_ctx.clearRect( 0 , 0 , self.canvas_save.width , self.canvas_save.height);

        for(var i = 0; i < self.pathData.length; i ++){
            self.viewCanvasDraw(self.pathData[i]);
        }
    });

    $('._pop_pen_pencil').find('button').on('click',function () {
        $('._pop_pen_marker').find('button').removeClass('select');
        $('._pop_pen_pencil').find('button').removeClass('select');
       $(this).addClass('select');
       self.color = $(this).attr('data-color');
       self.type = 'p';
    });

    $('._pop_pen_marker').find('button').on('click',function () {
        $('._pop_pen_marker').find('button').removeClass('select');
        $('._pop_pen_pencil').find('button').removeClass('select');
        $(this).addClass('select');
        self.color = $(this).attr('data-color');
        self.type = 'm';
    });

    $('._pop_pen_brush').find('button').on('click',function () {
        $('._pop_pen_brush').find('button').removeClass('select');
        $(this).addClass('select');
        if($(this).parent('li').index() == 0){
            self.brush = 'line';
        }else{
            self.brush = 'pen';
        }
    });

    $('._pop_pen_diameter').find('button').on('click',function () {
        $('._pop_pen_diameter').find('button').removeClass('select');
        $(this).addClass('select');
        self.size = 4 * ($(this).parent('li').index() + 1);
    });


    self.canvas.addEventListener('mousedown', pen.listener);
    self.canvas.addEventListener('mousemove', pen.listener);
    self.canvas.addEventListener('mouseup', pen.listener);

    self.canvas.addEventListener('touchstart', pen.listener);
    self.canvas.addEventListener('touchmove', pen.listener);
    self.canvas.addEventListener('touchend', pen.listener);
};




pen.listener = function (event) {

    if(pen.mouseEvent) {
        switch (event.type) {
            case 'mousedown':
            case 'touchstart':
                pen.drawWrap = true;
                pen.initDraw(event, pen.type, pen.color, pen.size);
                break;
            case 'mousemove':
            case 'touchmove':
                if(pos.drawable){
                    if(pen.drawWrap){
                        if (pen.brush === 'pen') {
                            pen.drawing(event);
                        }
                        if (pen.brush === 'line') {
                            pen.lineDrawing(event);
                        }
                    }else{
                        pen.drawingFinish(pen.brush);
                        break;
                    }
                }
                break;
            case 'mouseup':
            case 'touchend':
                pen.drawWrap = false;
                pen.drawingFinish(pen.brush);
                break;
        }
    }
};


pen.initDraw = function (event, type ,color, size) {
    var self = this;


    self.ctx.lineWidth = size;
    self.ctx.lineCap = 'round';

    if(type === 'p'){
        self.save_ctx.globalAlpha = 1;
        self.canvas.style.opacity = 1;
    }else if(type === 'm'){
        self.canvas.style.opacity = 0.5;
        self.save_ctx.globalAlpha = 0.5;
    }


    self.ctx.strokeStyle = color;

    pos.drawable = true;

    pos.x = event.offsetX;
    pos.y = event.offsetY;

    if(event.type === 'touchstart'){
        var canvasRect = pen.canvas_save.getBoundingClientRect();

        pos.x = (event.touches[0].clientX - canvasRect.left) / self.resizeValue;
        pos.y = (event.touches[0].clientY - canvasRect.top) / self.resizeValue;
    }

};

pen.drawing = function (event) {
    var self = this;
    var evnt_pos = self.getPosition(event);

    self.ctx.beginPath();
    self.ctx.moveTo(pos.x, pos.y);

    self.ctx.lineTo(evnt_pos.X_1, evnt_pos.Y_1);

    self.start_x.push(pos.x);
    self.start_y.push(pos.y);
    self.end_x.push(evnt_pos.X_1);
    self.end_y.push(evnt_pos.Y_1);


    pos.x = evnt_pos.X_1;
    pos.y = evnt_pos.Y_1;

    if(evnt_pos.X_1 < 5 || evnt_pos.Y_1 < 5 || evnt_pos.X_1 > 1180 || evnt_pos.Y_1 > 778){
        pen.drawWrap = false;
    }else {
        pen.drawWrap = true;
    }

    self.ctx.stroke();
};

pen.lineDrawing = function (event) {
    var self = this;
    var evnt_pos = self.getPosition(event);

    self.ctx.beginPath();

    // 이전꺼를 지운다
    self.ctx.clearRect( 0 , 0 , self.canvas.width , self.canvas.height);

    self.ctx.moveTo(pos.x, pos.y);
    self.ctx.lineTo(evnt_pos.X_1, evnt_pos.Y_1);


    temp_pos.start_x = pos.x;
    temp_pos.start_y = pos.y;
    temp_pos.end_x = evnt_pos.X_1;
    temp_pos.end_y = evnt_pos.Y_1;

    if(evnt_pos.X_1 < 5 || evnt_pos.Y_1 < 5 || evnt_pos.X_1 > 1180 || evnt_pos.Y_1 > 778){
        pen.drawWrap = false;
    }else {
        pen.drawWrap = true;
    }


    self.ctx.stroke();

    self.ctx.closePath();

};

pen.drawingFinish = function (brushType) {
    var self = this;
    var tempData;

    self.ctx.clearRect( 0 , 0 , self.canvas.width , self.canvas.height);

    if(brushType === 'pen'){
        tempData = {
            'strokeColor' : self.ctx.strokeStyle,
            'alpha' : self.save_ctx.globalAlpha,
            'lineWidth' : self.ctx.lineWidth,
            'lineCap' : self.ctx.lineCap,
            'start_x' : JSON.stringify(self.start_x),
            'start_y' : JSON.stringify(self.start_y),
            'end_x' : JSON.stringify(self.end_x),
            'end_y' : JSON.stringify(self.end_y),
            'brush' : self.brush
        };
    }

    if(brushType ==='line'){
        tempData = {
            'strokeColor' : self.ctx.strokeStyle,
            'alpha' : self.save_ctx.globalAlpha,
            'lineWidth' : self.ctx.lineWidth,
            'lineCap' : self.ctx.lineCap,
            'start_x' : temp_pos.start_x,
            'start_y' : temp_pos.start_y,
            'end_x' : temp_pos.end_x,
            'end_y' : temp_pos.end_y,
            'brush' : self.brush
        };
    }

    try {
        self.savePath(tempData);
    }catch (e) {
        console.error('pen savePath error :', e);
    }

    if(VIEWER.basic.isNW() === true){
        try {
            self.nwSaveData(self.pathData);
        } catch (e){
            console.error('pen nw save data error :', e);
        }
    }

    self.viewCanvasDraw(tempData);
    self.start_x.length = 0;
    self.start_y.length = 0;
    self.end_x.length = 0;
    self.end_y.length = 0;

    pos.drawable = false;
    pos.x = -1;
    pos.y = -1;
};


pen.getPosition = function (event) {
    var self =this;
    var x_1 = event.offsetX;
    var y_1 = event.offsetY;

    if(event.type === 'touchmove'){
        var canvasRect = pen.canvas_save.getBoundingClientRect();

        x_1 = (event.touches[0].clientX - canvasRect.left) / self.resizeValue;
        y_1 = (event.touches[0].clientY - canvasRect.top) / self.resizeValue;
    }

    return {
        X_1: x_1,
        Y_1: y_1
    }
};

//그릴때마다 패스를 저장한다.
pen.savePath = function (data) {
    var self = this;
    data.pageNum = VIEWER.global_value.displayPagesNum[0];
    self.pathData.push(data);
};


//그릴때마다 canvas_save로 불러온다
pen.viewCanvasDraw = function (data) {
    var self = this;

    self.save_ctx.lineWidth = data.lineWidth;
    self.save_ctx.strokeStyle = data.strokeColor;
    self.save_ctx.globalAlpha = data.alpha;

    // self.save_ctx.globalAlpha = 0.5;
    self.save_ctx.lineCap = data.lineCap;

    if(data.brush ==='line'){
        self.save_ctx.beginPath();
        self.save_ctx.moveTo(data.start_x, data.start_y);

        self.save_ctx.lineTo(data.end_x, data.end_y);

        self.save_ctx.stroke();
    }

    if(data.brush === 'pen'){

        var temp_start_x  = JSON.parse(data.start_x);
        var temp_start_y  = JSON.parse(data.start_y);
        var temp_end_x  = JSON.parse(data.end_x);
        var temp_end_y  = JSON.parse(data.end_y);


        self.save_ctx.beginPath();
        self.save_ctx.moveTo(temp_start_x[0], temp_start_y[0]);


        for( var i = 1; i < data.start_x.length; i ++){
            self.save_ctx.lineTo(temp_end_x[i], temp_end_y[i]);
        }

        self.save_ctx.stroke();
        self.save_ctx.closePath();

    }

};

pen.nwSaveData = function (data) {
    var self = this;
    VIEWER.storageCtrl.write(self.key, data);
};


pen.nwLoadData = function () {
    var self = this;

    self.save_ctx.clearRect( 0 , 0 , self.canvas_save.width , self.canvas_save.height);

    for(var i= 0; i < self.pathData.length; i ++){
        if(VIEWER.global_value.displayPagesNum[0] === self.pathData[i].pageNum){
            self.viewCanvasDraw(self.pathData[i]);
        }
    }
};


VIEWER.loadEvent.listen('_viewer_onLoad' , function(item) {
    try {
        pen.init();

        if(VIEWER.basic.isNW() === true) {

            //local data를 pathData 에 넣어준다.
            if(VIEWER.storageCtrl.read(pen.key)){
                for(var i = 0; i < VIEWER.storageCtrl.read(pen.key).length; i ++){
                    pen.pathData[i] = VIEWER.storageCtrl.read(pen.key)[i];
                }
            }

            try {
                pen.nwLoadData();
            } catch (e) {
                console.error('pen nw data load error :', e);
            }
        }
        VIEWER.frameLoadCtrl.leftFrameLoadEvt.listen('_viewerLeftPageLoad', function () {
            if(VIEWER.basic.isNW() === true) {
                try {
                    pen.nwLoadData();
                } catch (e) {
                    console.error('pen nw data load error :', e);
                }
            }else{
                pen.save_ctx.clearRect( 0 , 0 , pen.canvas.width , pen.canvas.height);
            }
        });


        VIEWER.layout.layerEvent.listen('_viewerResize' , function(data){
            pen.resizeValue = data.msg.scale;
            pen.resizeValue = parseFloat(pen.resizeValue);
        });

    } catch (e) {
        console.error('pen init error :', e);
    }
});




