
var help = {
    popupLayer : null,
    btn_help : null,
    btn_close : null
};

help.init = function () {
    var self = this;

    self.btn_help = document.querySelector('#_help');
    self.popupLayer = document.querySelector('#_pop_help');
    self.btn_close = document.querySelector('._btn_help_close');

    try {
        self.bindEvent();
    }catch (e){
        console.error('help bindEvent error :' , e);
    }

};

help.bindEvent = function () {
    var self = this;
    var viewer = document.querySelector('#viewer_wrap');

    /*투명 Layer : 다른 요소 클릭불가*/
    var dimLayer = null;
    dimLayer = document.createElement("div");
    dimLayer.classList.add('__dimLayer');
    viewer.appendChild(dimLayer);

    self.btn_help.addEventListener('click' , function () {
        self.popupLayer.classList.add('on');
        self.popupLayer.style.transform = 'translate(-50%, -50%)';
        self.popupLayer.style.left = '50%';
        self.popupLayer.style.top = '50%';
        dimLayer.classList.add('on');
    });

    self.btn_close.addEventListener('click',function () {
        self.popupLayer.classList.remove('on');
        dimLayer.classList.remove('on');
    });
};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        help.init();
    } catch (e) {
        console.error('help init error :', e);
    }
});




