var pageMove = {
    _head_next_btn : null,
    _head_prev_btn : null,
    _head_first_btn : null,
    _head_last_btn : null,
    _head_input_dom : null,
    _head_goTo_btn : null,


    _body_next_btn : null,
    _body_prev_btn : null

};

pageMove.init = function(){

    this._head_next_btn = document.querySelector('#_go_next_page button');
    this._head_prev_btn = document.querySelector('#_go_prev_page button');
    this._head_first_btn = document.querySelector('#_go_first_page button');
    this._head_last_btn = document.querySelector('#_go_last_page button');

    this._head_input_dom = document.querySelector('#_page_num input');
    this._head_goTo_btn = document.querySelector('#_go_page_move');

    this._body_next_btn = document.querySelector('#_btn_page_right');
    this._body_prev_btn = document.querySelector('#_btn_page_left');

    this.eventBind();
};


pageMove.eventBind = function(){

    var self = this;

    this._head_next_btn.addEventListener('click' , function(){
        var currentPageNum = VIEWER.global_value.displayPagesNum[1];
        if(currentPageNum +  VIEWER.global_value.displayPage <= VIEWER.global_value.lastPageNum){
            VIEWER.frameLoadCtrl.loadPage(currentPageNum +  VIEWER.global_value.displayPage);
        }else{
            alert('마지막 페이지 입니다.');
        }
    });
    this._body_next_btn.addEventListener('click' , function(){
        var currentPageNum = VIEWER.global_value.displayPagesNum[1];
        if(currentPageNum +  VIEWER.global_value.displayPage <= VIEWER.global_value.lastPageNum){
            VIEWER.frameLoadCtrl.loadPage(currentPageNum +  VIEWER.global_value.displayPage);
        } else {
            alert('마지막 페이지 입니다.');
        }
    });

    this._head_prev_btn.addEventListener('click' , function(){
        var currentPageNum = VIEWER.global_value.displayPagesNum[0];
        if(currentPageNum - VIEWER.global_value.displayPage >= VIEWER.global_value.startPageNum) {
            VIEWER.frameLoadCtrl.loadPage(currentPageNum - VIEWER.global_value.displayPage);
        } else {
            alert('첫 페이지 입니다.');
        }
    });

    this._body_prev_btn.addEventListener('click' , function(){
        var currentPageNum = VIEWER.global_value.displayPagesNum[0];
        if(currentPageNum - VIEWER.global_value.displayPage >= VIEWER.global_value.startPageNum) {
            VIEWER.frameLoadCtrl.loadPage(currentPageNum - VIEWER.global_value.displayPage);
        } else {
            alert('첫 페이지 입니다.');
        }
    });

    this._head_input_dom.addEventListener('focus' , function (){
        this.value = '';
    });

    this._head_goTo_btn.addEventListener('click' , function (){
        var pageNum = isNaN(self._head_input_dom.value);
        if(!pageNum){
            var statusVal = VIEWER.frameLoadCtrl.loadPage(Number(self._head_input_dom.value));
            if(statusVal != true){
                alert('페이지 번호를 확인하여 주십시요.');
            }
        } else {
            alert('숫자를 입력해 주십시요.');
        }
    });

    this._head_input_dom.addEventListener('keydown', function (e) {
        if(e.keyCode === 13){
            var pageNum = isNaN(self._head_input_dom.value);
            if(!pageNum){
                var statusVal = VIEWER.frameLoadCtrl.loadPage(Number(self._head_input_dom.value));
                if(statusVal != true){
                    alert('페이지 번호를 확인하여 주십시요.');
                }
            } else {
                alert('숫자를 입력해 주십시요.');
            }
        }
    });



    this._head_first_btn.addEventListener('click' , function (){
        VIEWER.frameLoadCtrl.loadPage(VIEWER.global_value.startPageNum);
    });
    this._head_last_btn.addEventListener('click' , function (){
        VIEWER.frameLoadCtrl.loadPage(VIEWER.global_value.lastPageNum);
    });
};

//로드
VIEWER.loadEvent.listen('_viewer_onLoad' , function(){
    try {
        pageMove.init();
    }catch (e){
        console.error('pageMove init error :' , e);
    }
});


