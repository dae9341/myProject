var zoom = {
    popupLayer : null,
    btn_zoom : null,
    btn_close : null,
    zoom_content :  null ,


    zoom_plus_btn : null,
    zoom_default_btn : null,
    zoom_minus_btn : null,

    control_layer_width : 300 ,
    control_layer_height : 197.5 ,

    content_layer : null ,
    content_layer_width : null ,
    content_layer_height : null ,

    min_scale_val : 1.5 ,
    max_scale_val : 5 ,

    start_y_position : 0,
    start_x_position : 0,


    control_handle_layer : null,
    control_handle_width : 0,
    control_handle_height : 0,

    wrapper_width : null,
    wrapper_height : null,

    control_handle_img_wrapper : null,

    //사용하고 있는 값
    setZoomVal : 1.5,
    set_x : 0,
    set_y : 0,

    //계산 값
    setCorrectionVal : null
};
zoom.init = function () {

    this.btn_zoom = document.querySelector('#_zoom');
    this.popupLayer = document.querySelector('#_pop_zoom');
    this.btn_close = this.popupLayer.querySelector('._btn_zoom_close');
    this._pop_zoom_content = document.querySelector('#_pop_zoom_content');

    this.control_handle_layer = document.querySelector('#_pop_zoom_content_handle');
    this.control_handle_img_wrapper = document.querySelector('#_pop_zoom_content_handle_img');


    this.content_layer = document.querySelector('#'+VIEWER.global_value.frameLayout.layer_domId);
    this.content_layer_width = VIEWER.global_value.frameLayout.width;
    this.content_layer_height = VIEWER.global_value.frameLayout.height;


    this.zoom_plus_btn = document.querySelector('#_zoom_plus_btn');
    this.zoom_default_btn = document.querySelector('#_zoom_default_btn');
    this.zoom_minus_btn = document.querySelector('#_zoom_minus_btn');

    try {
        this.bindEvent();
    } catch (e) {
        console.error('scale bindEvent error :' , e);
    }

};
zoom.bindEvent = function () {

    var self = this;

    this.btn_zoom.addEventListener('click' , function () {
        self.zoom_start(function(){
            self.popupLayer.classList.add('on');
        });
    });

    this.btn_close.addEventListener('click',function () {
        self.zoom_end(function() {
            self.popupLayer.classList.remove('on');
        });
    });


    this.zoom_plus_btn.addEventListener('click' , function(){
        if(self.setZoomVal + 0.5 <= self.max_scale_val){
            self.setZoomVal = self.setZoomVal + 0.5;
            if(self.setZoomVal >= self.max_scale_val){
                self.setZoomVal = self.max_scale_val;
            }
            self.zoomSet(self.setZoomVal , self.set_x , self.set_y);
        }
    });

    this.zoom_default_btn.addEventListener('click' , function(){
        self.setZoomVal = 1.5;
        self.zoomSet(self.setZoomVal , 0 , 0);
    });

    this.zoom_minus_btn.addEventListener('click' , function(){
        if(self.setZoomVal - 0.5 >= self.min_scale_val){
            self.setZoomVal = self.setZoomVal - 0.5;
            if(self.setZoomVal <= self.min_scale_val){
                self.setZoomVal = self.min_scale_val;
            }
            self.zoomSet(self.setZoomVal , self.set_x , self.set_y);
        }
    });

    this.controlLayerEvent();
};
zoom.zoom_start = function(callBack){

    //프레임 기본 셋팅 종료시 리셋
    this.content_layer.style.position = 'absolute';
    this.content_layer.style.top = '0px';
    this.content_layer.style.left = '0px';
    this.content_layer.style.zIndex = 2;
    this.content_layer.style.transformOrigin = '0 0 0';
    this.content_layer.style.background = 'white';

    document.querySelector('#viewer_content').style.overflow = 'hidden';
    document.querySelector('#viewer_content').style.height = '100%';
    document.querySelector('#viewer_content').style.top = '-76px';
    document.querySelector('#viewer_head').style.display = 'none';
    //프레임 기본 셋팅 종료시 리셋


    this.control_handle_img_wrapper.style.width = this.control_layer_width + 'px';
    this.control_handle_img_wrapper.style.width = this.control_layer_width + 'px';
    this.wrapper_width = document.querySelector('#viewer_content').offsetWidth;
    this.wrapper_height = document.querySelector('#viewer_content').offsetHeight;

    this.setCorrectionVal = this.content_layer_width / this.control_layer_width;

    this.setZoomVal = this.min_scale_val;

    zoom.thum_img_set();
    this.zoomSet(this.setZoomVal , this.start_x_position , this.start_y_position);

    if(callBack){
        callBack();
    }
};
zoom.zoom_end = function(callBack){

    this.content_layer.setAttribute('style' , '');
    this.content_layer.style.width = VIEWER.global_value.frameLayout.width + 'px';
    this.content_layer.style.height = VIEWER.global_value.frameLayout.height + 'px';

    document.querySelector('#viewer_content').setAttribute('style' , '');
    document.querySelector('#viewer_head').setAttribute('style' , '');

    this.content_layer.style.transform = 'none';

    if(callBack){
        callBack();
    }
};
//콘트롤 창에 사용하는 썸네일 이미지 셋팅
zoom.thum_img_set = function(){

    var appendImg_1 = document.createElement('img');
    var appendImg_2 = document.createElement('img');
    var appendImg_3 = document.createElement('img');
    var appendImg_4 = document.createElement('img');

    this._pop_zoom_content.innerHTML = '';
    this.control_handle_img_wrapper.innerHTML = '';

    appendImg_1.src = VIEWER.global_value.content_directory + 'thum_img/thum_page' + VIEWER.basic.matchNum(VIEWER.global_value.displayPagesNum[0] , 3) + '.jpg';
    appendImg_2.src = VIEWER.global_value.content_directory + 'thum_img/thum_page' + VIEWER.basic.matchNum(VIEWER.global_value.displayPagesNum[1] , 3) + '.jpg';
    appendImg_3.src = VIEWER.global_value.content_directory + 'thum_img/thum_page' + VIEWER.basic.matchNum(VIEWER.global_value.displayPagesNum[0] , 3) + '.jpg';
    appendImg_4.src = VIEWER.global_value.content_directory + 'thum_img/thum_page' + VIEWER.basic.matchNum(VIEWER.global_value.displayPagesNum[1] , 3) + '.jpg';

    appendImg_1.style.width = '50%';
    appendImg_2.style.width = '50%';
    appendImg_3.style.width = this.control_layer_width / 2 + 'px';
    appendImg_3.style.height = this.control_layer_height + 'px';
    appendImg_4.style.width = this.control_layer_width / 2 + 'px';
    appendImg_4.style.height = this.control_layer_height + 'px';


    this._pop_zoom_content.appendChild(appendImg_1);
    this._pop_zoom_content.appendChild(appendImg_2);

    this.control_handle_img_wrapper.appendChild(appendImg_3);
    this.control_handle_img_wrapper.appendChild(appendImg_4);
};
zoom.zoomSet = function(zoomVal  , x , y){

    if(!x) x = 0;
    if(!y) y = 0;

    var handle_scale_width = this.wrapper_width / this.setCorrectionVal;
    var handle_scale_height = this.wrapper_height / this.setCorrectionVal;

    this.control_handle_layer.style.width =  handle_scale_width / zoomVal + 'px';
    this.control_handle_layer.style.height =  handle_scale_height / zoomVal + 'px';

    if(x + (handle_scale_width / zoomVal) > this.control_layer_width){
        x =  x - ((x + handle_scale_width / zoomVal) - this.control_layer_width);
    }

    if(y + (handle_scale_height / zoomVal) > this.control_layer_height){
        y =  y - ((y + handle_scale_height / zoomVal) - this.control_layer_height);
    }

    this.set_x = x;
    this.set_y = y;

    this.content_layer.style.transform = 'scale(' + zoomVal + ') translateX(' + -(x * this.setCorrectionVal) + 'px) translateY(' + -(y * this.setCorrectionVal) + 'px)';
    this.control_handle_layer.style.top =  y + 'px';
    this.control_handle_layer.style.left = x + 'px';
    this.control_handle_img_wrapper.style.top =  -y + 'px';
    this.control_handle_img_wrapper.style.left = -x + 'px';
};
zoom.controlLayerEvent = function(){

    var self = this;
    var element = this.control_handle_layer;

    var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;

    element.addEventListener('mousedown' , dragMouseDown);

    function dragMouseDown(e) {
        e = e || window.event;
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
        document.querySelector('#_drag_helper_layer').style.display = 'block';
    }



    function elementDrag(e) {

        e = e || window.event;
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;
        
        var setPosX = 0;
        var setPosY = 0;

        if(element.offsetTop - pos2 <= 0){
            setPosY = 0;
        } else {
            setPosY = element.offsetTop - pos2;
        }
        if((setPosY + element.offsetHeight) >= self.control_layer_height){
            setPosY = self.control_layer_height - element.offsetHeight;
        }

        if(element.offsetLeft - pos1 <= 0){
            setPosX = 0;
        } else {
            setPosX = element.offsetLeft - pos1;
        }
        if((setPosX + element.offsetWidth) >= self.control_layer_width){
            setPosX = self.control_layer_width - element.offsetWidth;
        }


        element.style.top = setPosY + "px";
        element.style.left = setPosX + "px";

        self.zoomSet(self.setZoomVal , setPosX  , setPosY);


    }

    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
        document.querySelector('#_drag_helper_layer').style.display = 'none';
    }

};


zoom.contentLayerEvent = function(){

    var self = this;
    var element = this.content_layer;

    var pos1 = 0, pos2 = 0, pos3 = 0, pos4 = 0;

    element.addEventListener('mousedown' , dragMouseDown);

    function dragMouseDown(e) {
        e = e || window.event;
        pos3 = e.clientX;
        pos4 = e.clientY;
        document.onmouseup = closeDragElement;
        document.onmousemove = elementDrag;
        document.querySelector('#_drag_helper_layer').style.display = 'block';
    }

    function elementDrag(e) {
        e = e || window.event;
        pos1 = pos3 - e.clientX;
        pos2 = pos4 - e.clientY;
        pos3 = e.clientX;
        pos4 = e.clientY;

        var setPosX = 0;
        var setPosY = 0;

        if(element.offsetTop - pos2 <= 0){
            setPosY = 0;
        } else {
            setPosY = element.offsetTop - pos2;
        }
        if((setPosY + element.offsetHeight) >= self.control_layer_height){
            setPosY = self.control_layer_height - element.offsetHeight;
        }

        if(element.offsetLeft - pos1 <= 0){
            setPosX = 0;
        } else {
            setPosX = element.offsetLeft - pos1;
        }
        if((setPosX + element.offsetWidth) >= self.control_layer_width){
            setPosX = self.control_layer_width - element.offsetWidth;
        }

        element.style.top = setPosY + "px";
        element.style.left = setPosX + "px";

        self.zoomSet(self.setZoomVal , setPosX  , setPosY);
    }

    function closeDragElement() {
        document.onmouseup = null;
        document.onmousemove = null;
        document.querySelector('#_drag_helper_layer').style.display = 'none';
    }
};
VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        zoom.init();
    } catch (e) {
        console.error('zoom init error :', e);
    }
});