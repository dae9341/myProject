var memo = {
    key : VIEWER.global_value.content_directory + 'memo',
    popupLayer : null,
    btn_memo : null,
    popupLayer_header : null,
    memoLayer : null,
    memoIconDropLayer : null,
    memoIconLayer : null,
    memoIconImg : null,
    memoIconCloseBtn : null,
    cnt : 0,
    resizeValue : 0,
    iconStatus : false
};

var memo_tempData = [];

var memoPos = {
    x : 0,
    y : 0
};

var memoStorage = VIEWER.storageCtrl;

memo.init = function () {

    var self = this;

    self.btn_memo = document.querySelector('#_memo');

    self.resizeValue = document.querySelector('#viewer_wrap').style.transform.substring(28,34);
    self.resizeValue = parseFloat(self.resizeValue);


    try {
        self.bindEvent();
    }catch (e){
        console.error('memo bindEvent error :' , e);
    }

};

memo.loadData = function (pageNum) {

    var self = this;
    var memoPop_parent = document.querySelector('#_memo_container');

    //메모 레이어를 모두 지운다.
    var memoPop = $(memoPop_parent).find('._pop_memo');
    memoPop.remove();

    if(memoStorage.read(self.key)){
        memo_tempData = memoStorage.read(memo.key);

        for(var i = 0; i < memo_tempData.length; i ++){
            //해당 페이지의 메모만 layer 생성
            if(memo_tempData[i].page == pageNum){
                self.layerAdd(memo_tempData[i]);
            }
        }
    }
};

memo.layerAdd = function (pageNum) {
    var self = this;


    var memo_addData = {
        'page' : '',
        'memoIndex' : '',
        'text' : '',
        'x' : '',
        'y' : '',
        'iconStatus' : ''
    };

    var memoWrap = document.querySelector('#_memo_container');

    var _pop_memo = document.createElement('div');
    var _pop_memo_inner = document.createElement('div');
    var _pop_memo_header = document.createElement('div');
    var _pop_memo_content = document.createElement('div');
    var __pop_memo_dropLayer = document.createElement('div');

    memoWrap.appendChild(_pop_memo);
    _pop_memo.appendChild(_pop_memo_inner);
    _pop_memo_inner.appendChild(_pop_memo_header);
    _pop_memo_inner.appendChild(_pop_memo_content);
    _pop_memo.appendChild(__pop_memo_dropLayer);

    _pop_memo.classList.add('_pop_memo');
    _pop_memo_inner.classList.add('_pop_memo_inner');
    _pop_memo_header.classList.add('_pop_memo_header');
    _pop_memo_header.classList.add('__memo_handle');
    _pop_memo_content.classList.add('_pop_memo_content');
    __pop_memo_dropLayer.classList.add('__pop_memo_dropLayer');



    _pop_memo_header.innerHTML = '<span>메모</span>';
    $(_pop_memo_inner).append('<button class="_btn_memo_save"></button><button class="_btn_memo_close"></button>');
    _pop_memo_content.innerHTML = '<textarea></textarea>';

    __pop_memo_dropLayer.innerHTML = ' <div class="__pop_memo_icon"> <img class="__icon_memo __memo_handle" src="img/modules/memo/ico_memo_temp.png"/> <img class="__icon_popup" src="img/modules/memo/ico_close_temp.png"/> </div>';


    if(typeof pageNum == 'object'){
        memoPos.x = pageNum.x;
        memoPos.y = pageNum.y;
        _pop_memo.style.left = pageNum.x;
        _pop_memo.style.top = pageNum.y;
        self.cnt = pageNum.memoIndex;

        _pop_memo.querySelector('textarea').value = pageNum.text;

        if(pageNum.iconStatus === true){
            __pop_memo_dropLayer.style.display = 'block';
            _pop_memo_inner.style.display = 'none';
            self.iconStatus = pageNum.iconStatus;
        }

    }else if(typeof pageNum === 'number'){
        memoPos.x = memoPos.x + 50;
        memoPos.y = memoPos.y + 50;
        _pop_memo.style.left = memoPos.x + 'px';
        _pop_memo.style.top = memoPos.y + 'px';

        for(var i = 0; i < memo_tempData.length; i ++){
            if(memo_tempData[i].page == pageNum){
                if(memo_tempData[i].memoIndex >= self.cnt){
                    self.cnt = memo_tempData[i].memoIndex + 1;
                }
            }
        }
    }



    _pop_memo.setAttribute('data-index', self.cnt);
    self.popupLayer = _pop_memo;

    memo_addData.page = pageNum;
    memo_addData.memoIndex = self.cnt;
    memo_addData.x = _pop_memo.style.left;
    memo_addData.y = _pop_memo.style.top;
    memo_addData.iconStatus = self.iconStatus;

    if(typeof pageNum == 'number'){
        memo_tempData.push(memo_addData);
        memoStorage.write(self.key , memo_tempData);
    }


    try {
        self.bind_popupEvent();
    }catch (e){
        console.error('memo bind_popupEvent error :' , e);
    }


    $(self.popupLayer).draggable({
        containment :'#_content',
        handle : '.__memo_handle',

        start: function(event , ui){
            $('#_memo_drag_helper_layer').show();
            $('#viewer_wrap').css('position','fixed');
            popupLayer_click.x = event.clientX;
            popupLayer_click.y = event.clientY;
        },

        drag:function (event, ui) {

            var original = ui.originalPosition;
            ui.position = {
                left: (event.clientX - popupLayer_click.x + original.left) / memo.resizeValue,
                top:  (event.clientY - popupLayer_click.y + original.top) / memo.resizeValue
            };

            var maxLeft = ui.helper[0].parentNode.parentNode.offsetWidth  - ui.helper[0].offsetWidth;
            var maxTop = ui.helper[0].parentNode.parentNode.offsetHeight  - ui.helper[0].offsetHeight;


            if(ui.position.left < 0){
                ui.position.left = 0;
            }
            if(ui.position.top < 0){
                ui.position.top = 0;
            }
            if(ui.position.top > maxTop){
                ui.position.top = maxTop;
            }
            if(ui.position.left > maxLeft){
                ui.position.left = maxLeft;
            }

        },

        stop : function(event , ui){
            $('#_memo_drag_helper_layer').hide();
            $('#viewer_wrap').css('position','absolute');
            var original = ui.originalPosition;
            ui.position = {
                left: (event.clientX - popupLayer_click.x + original.left) / memo.resizeValue,
                top:  (event.clientY - popupLayer_click.y + original.top) / memo.resizeValue
            };

            memo.saveMemo(VIEWER.global_value.displayPagesNum[0], this);
        }
    });
};

memo.bindEvent = function () {

    var self = this;



    self.btn_memo.addEventListener('click' , function () {

        try {
            self.layerAdd(VIEWER.global_value.displayPagesNum[0]);
        }catch (e){
            console.error('memo layerAdd error :' , e);
        }


    });

};

memo.bind_popupEvent = function () {

    var self = this;

    var memoWrap = document.querySelector('#_memo_container');

    var memo_popup = memoWrap.querySelectorAll('._pop_memo');

    var memo_closeBtn = self.popupLayer.querySelector('._btn_memo_close');
    var memo_saveBtn = self.popupLayer.querySelector('._btn_memo_save');
    var memo_iconBtn = self.popupLayer.querySelector('.__icon_popup');

    var memo_textarea = self.popupLayer.querySelector('textarea');

    memo_closeBtn.addEventListener('click', function () {
        var deleteArray_num = null;
        var memo_thisPopup = this.parentNode.parentNode;

        for(var i = 0; i < memo_tempData.length; i++){
            if(memo_tempData[i].page == VIEWER.global_value.displayPagesNum[0] && memo_tempData[i].memoIndex == memo_thisPopup.getAttribute('data-index')){
                deleteArray_num = i;
            }
        }
        memo_tempData.splice(deleteArray_num, 1);
        memoStorage.write(memo.key , memo_tempData);

        memoWrap.removeChild(memo_thisPopup);
    });

    memo_saveBtn.addEventListener('click' , function () {
        self.iconStatus = true;
        self.saveMemo(VIEWER.global_value.displayPagesNum[0], this.parentNode.parentNode);
        this.parentNode.parentNode.querySelector('.__pop_memo_dropLayer').style.display = 'block';
        this.parentNode.style.display = 'none';
        // this.parentNode.parentNode.setAttribute('data-iconStatus', true);
    });

    memo_textarea.onchange = function () {
        self.iconStatus = false;
        self.saveMemo(VIEWER.global_value.displayPagesNum[0], this.parentNode.parentNode.parentNode);
    };

    memo_iconBtn.addEventListener('click', function () {
        self.iconStatus = false;
        self.saveMemo(VIEWER.global_value.displayPagesNum[0], this.parentNode.parentNode.parentNode);
        this.parentNode.parentNode.style.display = 'none';
        this.parentNode.parentNode.parentNode.querySelector('._pop_memo_inner').style.display = 'block';
        // this.parentNode.parentNode.parentNode.setAttribute('data-iconStatus', false);
    });

};


memo.saveMemo = function (pageNum, dom) {
    var self = this;

    var textContent = dom.querySelector('textarea').value;
    var thisPage_index = dom.getAttribute('data-index');

    for(var i = 0; i < memo_tempData.length; i ++){
        if(memo_tempData[i].page == pageNum && memo_tempData[i].memoIndex == thisPage_index){
            memo_tempData[i].iconStatus = self.iconStatus;
            memo_tempData[i].text = textContent;
            memo_tempData[i].x = dom.style.left;
            memo_tempData[i].y = dom.style.top;
        }
    }

    memoStorage.write(self.key, memo_tempData);
};




VIEWER.loadEvent.listen('_viewer_onLoad' , function(){
    try {
        memo.init();
    }catch (e){
        console.error('memo init error :' , e);
    }

    $('._pop_memo').draggable({
        containment :'#_content',
        handle : '.__memo_handle',

        start: function(event , ui){
            $('#_memo_drag_helper_layer').show();
            $('#viewer_wrap').css('position','fixed');
            popupLayer_click.x = event.clientX;
            popupLayer_click.y = event.clientY;
        },

        drag:function (event, ui) {

            var original = ui.originalPosition;
            ui.position = {
                left: (event.clientX - popupLayer_click.x + original.left) / memo.resizeValue,
                top:  (event.clientY - popupLayer_click.y + original.top) / memo.resizeValue
            };


            var maxLeft = ui.helper[0].parentNode.parentNode.offsetWidth  - ui.helper[0].offsetWidth;
            var maxTop = ui.helper[0].parentNode.parentNode.offsetHeight  - ui.helper[0].offsetHeight;


            if(ui.position.left < 0){
                ui.position.left = 0;
            }
            if(ui.position.top < 0){
                ui.position.top = 0;
            }
            if(ui.position.top > maxTop){
                ui.position.top = maxTop;
            }
            if(ui.position.left > maxLeft){
                ui.position.left = maxLeft;
            }

        },

        stop : function(event , ui){
            $('#_memo_drag_helper_layer').hide();
            $('#viewer_wrap').css('position','absolute');
            var original = ui.originalPosition;
            ui.position = {
                left: (event.clientX - popupLayer_click.x + original.left) / memo.resizeValue,
                top:  (event.clientY - popupLayer_click.y + original.top) / memo.resizeValue
            };

            memo.saveMemo(VIEWER.global_value.displayPagesNum[0], this);
        }



    });
});

VIEWER.frameLoadCtrl.leftFrameLoadEvt.listen('_viewerLeftPageLoad', function () {
    try {
        memo.loadData(VIEWER.global_value.displayPagesNum[0]);
        memoPos.x = 0;
        memoPos.y = 0;
    }catch (e){
        console.error('memo bindEvent error :' , e);
    }
});

VIEWER.layout.layerEvent.listen('_viewerResize' , function(data){
    memo.resizeValue = data.msg.scale;
    memo.resizeValue = parseFloat(memo.resizeValue);
});


var popupLayer_click = {
    x: 0,
    y: 0
};
