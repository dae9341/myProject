var dataRoomAdd = {
    pagePath : null ,
    wordPage_iframe : null ,
    wordPage_btn : null ,
    wordPage_layer : null,
    wordPage_closeBtn : null
};


dataRoomAdd.init = function(){

    this.pagePath = VIEWER.global_value.content_directory + 'dataRoom/dataRoom.html';
    this.wordPage_btn = document.querySelector('#_data_room button');
    this.wordPage_iframe = document.querySelector('#data_room_frame');
    this.wordPage_layer = document.querySelector('#_pop_data_room');
    this.wordPage_closeBtn = document.querySelector('#_pop_data_room_header ._btn_data_room_close');
    this.wordPage_iframe.src = this.pagePath;




    this.evtBind();
};

dataRoomAdd.evtBind = function(){

    var self = this;

    this.wordPage_btn.addEventListener('click' , function(){
        self.wordPage_layer.style.display = 'block';
    });

    this.wordPage_closeBtn.addEventListener('click' , function(){
        self.wordPage_layer.style.display = 'none';
    });
};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        dataRoomAdd.init();
    } catch (e) {
        console.error('dataRoomAdd init error :', e);
    }
});