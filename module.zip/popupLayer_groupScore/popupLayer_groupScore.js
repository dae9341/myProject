var popup_groupScore = {
    popup_dimLayer :null,
    popupLayer : null,
    btn_groupScore : null,

    scoreLayer_default : null,
    scoreLayer_active : null,

    btn_defaultStart : null,
    btn_defaultClose : null,
    btn_activeClose : null,
    btn_activeBack : null,

    _sticker_box : null,
    _sticker_plus : null,
    _sticker_minus : null,

    groupCnt : 2,
    stickerCnt : null,
    stickerCntLayer : null

};

popup_groupScore.init = function () {
    var self = this;


    self.popup_dimLayer = document.querySelector('#_popupLayer_layer');
    self.btn_groupScore = document.querySelector('#_popupLayer_score');
    self.popupLayer = document.querySelector('#_scoreLayer');

    self.scoreLayer_default = self.popupLayer.querySelector('._scoreLayer_default');
    self.btn_defaultClose = self.popupLayer.querySelector('._popupLayer_layer_close');
    self.btn_defaultStart = self.popupLayer.querySelector('._sticker_chk');

    self.scoreLayer_active = self.popupLayer.querySelector('._scoreLayer_active');
    self.btn_activeClose = self.popupLayer.querySelector('._sticker_close');
    self.btn_activeBack = self.popupLayer.querySelector('._sticker_reset');

    self._sticker_box = self.popupLayer.querySelector('._sticker_box');
    self._sticker_plus = self.popupLayer.querySelector('._sticker_plus');
    self._sticker_minus = self.popupLayer.querySelector('._sticker_minus');

    self.stickerCntLayer = self.popupLayer.querySelector('._sticker_num');
    self.stickerCnt = self.stickerCntLayer.textContent;

    try {
        self.bindEvent();
    }catch (e){
        console.error('groupScore bindEvent error :' , e);
    }
};

popup_groupScore.bindEvent = function () {
    var self = this;

    self.btn_groupScore.addEventListener('click', function () {
        self.popupLayer.style.display = 'block';
        self.popup_dimLayer.classList.add('on');
        self.scoreLayer_default.classList.add('on');
    });

    //선택화면 닫기
    self.btn_defaultClose.addEventListener('click', function () {
        self.popupLayer.style.display = 'none';
        self.popup_dimLayer.classList.remove('on');
        self.scoreLayer_default.classList.remove('on');
    });

    //선택화면 확인
    self.btn_defaultStart.addEventListener('click', function () {
        self.scoreStart();
        self.scoreLayer_default.classList.remove('on');
        self.scoreLayer_active.classList.add('on');
    });

    //점수판 닫기
    self.btn_activeClose.addEventListener('click', function () {
        self.reset();
        self.popupLayer.style.display = 'none';
        self.popup_dimLayer.classList.remove('on');
        self.scoreLayer_default.classList.remove('on');
        self.scoreLayer_active.classList.remove('on');

    });

    //점수판 reset
    self.btn_activeBack.addEventListener('click', function () {
        self.reset();
        self.scoreLayer_default.classList.add('on');
        self.scoreLayer_active.classList.remove('on');
    });

    //스티커 ++
    self._sticker_plus.addEventListener('click', function () {

        if(self.stickerCnt < 20){
            self.stickerCnt ++;
            self.stickerCntLayer.textContent = self.stickerCnt;
        }else{
            return false;
        }

    });

    //스티커 --
    self._sticker_minus.addEventListener('click', function () {

        if(self.stickerCnt > 1) {
            self.stickerCnt--;
            self.stickerCntLayer.textContent = self.stickerCnt;
        }else{
            return false;
        }
    });


    //모둠 수 get
    $(self._sticker_box ).find('._sticker').on('click', function () {
        $(self._sticker_box ).find('._sticker').removeClass('on');
        $(this).addClass('on');
        self.groupCnt = $(this).index() + 2;
    });

};

popup_groupScore.scoreStart = function () {
    var self = this;

    for(var i = 0; i < self.groupCnt; i ++){
        self.scoreLayerSet( i , self.stickerCnt);
    }


    $(self.scoreLayer_active).find('._sticker_list_content p').on('click', function () {
        var btnStatus = $(this).hasClass('on');
        if(!btnStatus){
            $(this).addClass('on');
        }else{
            $(this).removeClass('on');
        }

    });


    if(self.stickerCnt > 10){
        $(self.scoreLayer_active).find('._sticker_list').addClass('_sticker_small');
    }

};

popup_groupScore.scoreLayerSet = function (grounpCnt, stickerCnt) {
    var self = this;
    var devideValue, heightValue, br_index;
    if(self.groupCnt % 2 === 0){
        devideValue = self.groupCnt / 2;
    }else{
        devideValue = Math.floor(self.groupCnt / 2) + 1;
    }

    if(stickerCnt % 2 === 0) {
        br_index = Math.floor(stickerCnt / 2);
    }else{
        br_index = Math.floor(stickerCnt / 2) + 1;
    }


    heightValue = 100 / devideValue;

    $(self.scoreLayer_active).append('<div class="_sticker_list" style="height: ' + heightValue + '%;"><div class="_sticker_list_inner"><div class="_sticker_list_content"><span class="_sticker_list_head">' + (grounpCnt + 1) + '</span></div></div></div>');

    for(var i = 0; i < stickerCnt; i ++){
        if( i + 1 === br_index){
            $('._sticker_list_content').eq(grounpCnt).append('<p></p><br>');
        }else{
            $('._sticker_list_content').eq(grounpCnt).append('<p></p>');
        }
    }

};

popup_groupScore.reset = function () {
    var self = this;
    $(self.scoreLayer_active).find('._sticker_list').remove();
};

VIEWER.loadEvent.listen('_viewer_onLoad' , function() {
    try {
        popup_groupScore.init();
    } catch (e) {
        console.error('groupScore init error :', e);
    }
});


